plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForConditions <-
function(sortvar, modality, clusterID, conditions, 
                   modelSignificance,
                   annotationPattern, 
                   subjectsAndComponents, 
                   analyzedConditionsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   behavioralMeasuresFilenamePattern,
                   plotsFilenamePattern,
                   xCorCoefAnnotation, yCorCoefAnnotation, 
                   hjust, vjust,
                   sizeLabels, sizeAnnotations, xlab, ylab, main, 
                   width, height, ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotFilename <- sprintf(plotsFilenamePattern, 
                                 clusterID,
                                 modality, 
                                 sortvar, 
                                 clusterID, 
                                 condition)
        trellis.device("postscript", width=width, height=height, onefile=FALSE,
                                      horizontal=FALSE, file=plotFilename)
        plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForSubjects(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         modelSignificance=modelSignificance,
         annotationPattern=annotationPattern,
         subjectsAndComponents=subjectsAndComponents,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern, 
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         behavioralMeasuresFilenamePattern=behavioralMeasuresFilenamePattern,
         xlab=xlab,
         ylab=ylab,
         main=main,
         xCorCoefAnnotation=xCorCoefAnnotation,
         yCorCoefAnnotation=yCorCoefAnnotation,
         hjust=hjust, vjust=vjust,
         sizeLabels=sizeLabels, 
         sizeAnnotations=sizeAnnotations,
         ...)
        dev.off()
    }
}
