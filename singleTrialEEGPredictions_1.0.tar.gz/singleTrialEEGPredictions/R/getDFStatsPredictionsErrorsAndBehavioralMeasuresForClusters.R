getDFStatsPredictionsErrorsAndBehavioralMeasuresForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                   filterSFPStatsFunc,
                   filterDFPStatsFunc, 
                   getUnselectedSFPStats, 
                   getUnselectedDFPStats, 
                   getSFPAndDFPStatsForSubjectAndComponentFunc,
                   getSFPStatsForSubjectAndComponentFunc,
                   sFPStatsForClusters, 
                   dFPStatsForSubjects, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   modelSignificance) {
    df <- data.frame()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        sFPStatsForConditions <- 
         getItemInAVShiftList(listOfItems=sFPStatsForClusters,
                               listFieldName="stats",
                               keyFieldNames=c("clusterID"),
                               keyFieldValues=c(clusterID))
        conditionsDF <- 
        getDFStatsPredictionsErrorsAndBehavioralMeasuresForConditions( 
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         conditions=conditions,
         filterSFPStatsFunc=filterSFPStatsFunc,
         filterDFPStatsFunc=filterDFPStatsFunc,
         getUnselectedSFPStats=getUnselectedSFPStats,
         getUnselectedDFPStats=getUnselectedDFPStats,
         getSFPAndDFPStatsForSubjectAndComponentFunc=
          getSFPAndDFPStatsForSubjectAndComponentFunc,
         getSFPStatsForSubjectAndComponentFunc=
          getSFPStatsForSubjectAndComponentFunc,
         sFPStatsForConditions=sFPStatsForConditions,
         dFPStatsForSubjects=dFPStatsForSubjects,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         modelSignificance=modelSignificance)
        df <- rbind(df, conditionsDF)
    }
    return(df)
}
