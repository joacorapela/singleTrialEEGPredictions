plotSubjectsDipolesAndCorCoefs2ForConditions <-
function(sortvar, modality, conditions, subjectsNames, clustersIDs,
                   modelSignificance, scaleLimit, pointSize,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   dipfitInfoFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotSubjectsDipolesAndCorCoefs2ForSubjects(
         sortvar=sortvar, 
         modality=modality, 
         condition=condition, 
         subjectsNames=subjectsNames,
         clustersIDs=clustersIDs, 
         modelSignificance=modelSignificance,
         scaleLimit=scaleLimit,
         pointSize=pointSize,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         dipfitInfoFilenamePattern=dipfitInfoFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, 
         height=height, ...)
    }
}
