plotRegLMCoefficientsForSubjectsAndComponents <-
function(sortvar, 
           modality, 
           clusterID, 
           condition, 
           unstandardize,
           subjectsAndComponents,
           minSFPDs, maxSFPDs,
           analyzedConditionsFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ...) { 
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        for(minSFPD in minSFPDs) {
            for(maxSFPD in maxSFPDs) {
                analyzedConditionFilename <- 
                 sprintf(analyzedConditionsFilenamePattern,
                          clusterID,
                          clusterID,
                          condition,
                          sortvar,
                          modality,
                          subjectName,
                          component,
                          minSFPD,
                          maxSFPD)
                if(!file.exists(analyzedConditionFilename)) {
                    break
                }
                show(sprintf("Processing %s%02d: minSFPD %d, maxSFPD %d",
                             subjectName, component, minSFPD, maxSFPDs[i]))
                sAnalyzedCondition <- get(load(analyzedConditionFilename))
                meanTimeRegressors <- sAnalyzedCondition$meanTimeRegressors
                show(sprintf("Processing subject %s and comonent %02d", 
                             subjectName, component))
                plotFilename <- sprintf(plotsFilenamePattern, 
                                         clusterID,
                                         condition,
                                         sortvar,
                                         modality,
                                         subjectName,
                                         component,
                                         minSFPD,
                                         maxSFPD)
                coefsCIs <- sAnalyzedCondition$coefsCIs
                if(!is.null(coefsCIs)) {
                    if(unstandardize) {
                        scale <- attr(sAnalyzedCondition$data, "scaled:scale")
                        scaleY <- scale[1]
                        scaleX <- scale[-1]
                        center <- attr(sAnalyzedCondition$data, "scaled:center")
                        centerY <- center[1]
                        centerX <- center[-1]
                        coefsCIs <- unstandardizeCoefs(standardizedCoefs=
                                                         coefsCIs[-1,], 
                                                        centerX=centerX,
                                                        scaleX=scaleX,
                                                        centerY=centerY,
                                                        scaleY=scaleY)
                    }
                    plotRegLMCoefficients(coefsCIs=coefsCIs,
                                           times=sAnalyzedCondition$times,
                                           itc=sAnalyzedCondition$itc,
                                           meanDirection=
                                            sAnalyzedCondition$meanDirection,
                                           xlim=xlim,
                                           ...)
                    ggsave(filename=plotFilename)
               }
            }
        }
    }
}
