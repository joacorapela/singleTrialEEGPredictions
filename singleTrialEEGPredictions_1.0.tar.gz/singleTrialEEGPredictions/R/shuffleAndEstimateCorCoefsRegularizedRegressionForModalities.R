shuffleAndEstimateCorCoefsRegularizedRegressionForModalities <-
function(modalities, sortvar, clustersIDs, conditions, 
                      subjectsAndComponents, 
                      preProcessedPhaseERPIFilenamePattern, 
                      corCoefsFilenamePattern, 
                      minSFPDs, maxSFPDs, lambda, order, scaleData, 
                      nGroups, 
                      a0, b0, c0, d0, maxIter, convergenceTol, nShuffles) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        shuffleAndEstimateCorCoefsRegularizedRegressionForClusters(
         modality=modality, 
         sortvar=sortvar, 
         clustersIDs=clustersIDs, 
         conditions=conditions, 
         subjectsAndComponents=subjectsAndComponents,
         preProcessedPhaseERPIFilenamePattern=preProcessedPhaseERPIFilenamePattern,
         corCoefsFilenamePattern=corCoefsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, 
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nShuffles=nShuffles)
    }
}
