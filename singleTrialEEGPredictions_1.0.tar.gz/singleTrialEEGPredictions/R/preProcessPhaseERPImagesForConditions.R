preProcessPhaseERPImagesForConditions <-
function(sortvar, 
           modality, 
           clusterID, 
           conditions, 
           subjectsAndComponents,
           srate,
           clipFrom, clipTo,
           alignmentSignificance,
           plotSteps,
           averageTrialsWinSize,
           plotsFilenamePattern,
           width, height,
           xlim, zlim,
           phaseERPImageFilenamePattern,
           preProcessedPhaseERPIFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        apERPImages <- 
         preProcessPhaseERPImagesForCondition(
          sortvar=sortvar, 
          modality=modality,
          clusterID=clusterID,
          condition=condition,
          subjectsAndComponents=subjectsAndComponents,
          srate=srate,
          clipFrom=clipFrom,
          clipTo=clipTo,
          alignmentSignificance=alignmentSignificance,
          plotSteps=plotSteps,
          averageTrialsWinSize=averageTrialsWinSize,
          plotsFilenamePattern=plotsFilenamePattern,
          width=width, height=height,
          xlim=xlim, zlim=zlim, 
          phaseERPImageFilenamePattern=phaseERPImageFilenamePattern,
          preProcessedPhaseERPIFilenamePattern=
           preProcessedPhaseERPIFilenamePattern)
    }
}
