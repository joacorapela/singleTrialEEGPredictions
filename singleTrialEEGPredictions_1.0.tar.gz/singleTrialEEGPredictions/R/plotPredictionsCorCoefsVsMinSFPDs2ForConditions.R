plotPredictionsCorCoefsVsMinSFPDs2ForConditions <-
function(sortvar, modality, clusterID, conditions, minSFPDs, maxSFPD,
                   nResamples, modelSignificance, rConf,
                   subjectsAndComponents, 
                   analyzedConditionsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotPredictionsCorCoefsVsMinSFPDs2ForSubjectsAndComponents(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         minSFPDs=minSFPDs,
         maxSFPD=maxSFPD,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         rConf=rConf,
         subjectsAndComponents=subjectsAndComponents,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern, 
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab,
         ylab=ylab,
         main=main,
         ...)
    }
}
