plotMediansOfPredictionsErrorsForHitsAndMisses3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                   getStatsDifAnnotationFunction,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, 
                   maxSTD_D_delay,
                   maxDFPD,
                   nResamples, conf,
                   subjectsAndComponents,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotMediansOfPredictionsErrorsForHitsAndMisses3ForClusters(
         sortvar=sortvar, 
         modality=modality,
         clustersIDs=clustersIDs, 
         conditions=conditions,
         getStatsDifAnnotationFunction=getStatsDifAnnotationFunction,
         dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
         rtsInfo=rtsInfo,
         dfpdsInfo=dfpdsInfo,
         maxRT=maxRT,
         maxSTD_D_delay=maxSTD_D_delay,
         maxDFPD=maxDFPD,
         nResamples=nResamples,
         conf=conf,
         subjectsAndComponents=subjectsAndComponents,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         ...)
    }
}
