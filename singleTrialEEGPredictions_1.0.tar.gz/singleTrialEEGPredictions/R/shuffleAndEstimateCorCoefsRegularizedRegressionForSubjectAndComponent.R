shuffleAndEstimateCorCoefsRegularizedRegressionForSubjectAndComponent <-
function(modality, sortvar, clusterID, condition, 
                    subjectName,
                    component,
                    preProcessedPhaseERPIFilenamePattern, 
                    corCoefsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, maxIter, convergenceTol, nShuffles) {
    preProcessedPhaseERPIFilename <- 
     sprintf(preProcessedPhaseERPIFilenamePattern, 
              clusterID,
              condition,
              sortvar,
              modality,
              subjectName,
              component)
    preProcessedPhaseERPI <- get(load(preProcessedPhaseERPIFilename))
    for(minSFPD in minSFPDs) {
        i <- 1
        while(i<=length(maxSFPDs) && 
               maxSFPDs[i]<=max(preProcessedPhaseERPI$sfpds)) {
            if(maxSFPDs[i]<minSFPD) {
                next
            }
            show(sprintf("Processing %s%02d: minSFPD %d, maxSFPD %d",
                         subjectName, component, minSFPD, maxSFPDs[i]))
            maxSFPD <- maxSFPDs[i]
            corCoefsFilename <- 
             sprintf(corCoefsFilenamePattern, clusterID, condition,
                                              sortvar, modality, subjectName, 
                                              component, minSFPD, maxSFPD)
            corCoefs <- shuffleAndEstimateCorCoefsRegularizedRegression(
                         erpImage=preProcessedPhaseERPI, 
                         minSFPD=minSFPD,
                         maxSFPD=maxSFPD,
                         lambda=lambda,
                         order=order,
                         scaleData=scaleData, 
                         nGroups=nGroups,
                         a0=a0, b0=b0, c0=c0, d0=d0, 
                         maxIter=maxIter,
                         convergenceTol=convergenceTol,
                         nShuffles=nShuffles)
            save(corCoefs, file=corCoefsFilename)
            i <- i+1
        }
    }
}
