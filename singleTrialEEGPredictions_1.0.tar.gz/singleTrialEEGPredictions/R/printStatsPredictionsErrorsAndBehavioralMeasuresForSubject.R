printStatsPredictionsErrorsAndBehavioralMeasuresForSubject <-
function(modality, clusterID, condition, subjectName, component,
                    sFPStatsForSubject, 
                    selectedDFPStats, 
                    modelPredictionCI,
                    filterSFPStatsFunc,
                    filterDFPStatsFunc, 
                    printUnselectedSFPStats, 
                    printUnselectedDFPStats, 
                    printSFPAndDFPStatsFunc,
                    printSFPStatsFunc,
                    con) {
    filteredSFPStats <- filterSFPStatsFunc(sFPStatsForSubject)
    filteredDFPStats <- filterDFPStatsFunc(selectedDFPStats)
    if((filteredSFPStats && filteredDFPStats) || 
       (filteredSFPStats && !filteredDFPStats && printUnselectedDFPStats) ||
       (!filteredSFPStats && filteredDFPStats && printUnselectedSFPStats) ||
       (!filteredSFPStats && !filteredDFPStats && printUnselectedSFPStats &&
        printUnselectedDFPStats)) {
        printSFPAndDFPStatsFunc(modality=modality, 
                                 clusterID=clusterID,
                                 condition=condition,
                                 subjectName=subjectName,
                                 component=component,
                                 sFPStatsForSubject=sFPStatsForSubject, 
                                 selectedDFPStats=selectedDFPStats,
                                 filteredSFPStats=filteredSFPStats,
                                 filteredDFPStats=filteredDFPStats, 
                                 con=con)
    } else {
        if((filteredSFPStats && !filteredDFPStats && 
                                !printUnselectedDFPStats) ||
           (!filteredSFPStats && !filteredDFPStats &&
                                   printUnselectedSFPStats && 
                                   !printUnselectedDFPStats)) {
            printSFPStatsFunc(modality=modality, 
                               clusterID=clusterID,
                               condition=condition,
                               subjectName=subjectName,
                               component=component,
                               sFPStatsForSubject=sFPStatsForSubject, 
                               filteredSFPStats=filteredSFPStats,
                               con=con)
        }
    }
}
