preProcessPhaseERPImagesForModalities <-
function(sortvar, 
           modalities, 
           clustersIDs, 
           conditions, 
           srate,
           clipFrom, clipTo,
           alignmentSignificance,
           plotSteps,
           averageTrialsWinSize,
           plotsFilenamePattern,
           width, height,
           xlim, zlim,
           scFilenamePattern,
           phaseERPImageFilenamePattern,
           preProcessedPhaseERPIFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        preProcessPhaseERPImagesForClusters(
         sortvar=sortvar, 
         modality=modality,
         clustersIDs=clustersIDs,
         conditions=conditions,
         srate=srate,
         clipFrom=clipFrom,
         clipTo=clipTo,
         alignmentSignificance=alignmentSignificance,
         plotSteps=plotSteps,
         averageTrialsWinSize=averageTrialsWinSize,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         xlim=xlim, zlim=zlim, 
         scFilenamePattern=scFilenamePattern,
         phaseERPImageFilenamePattern=phaseERPImageFilenamePattern,
         preProcessedPhaseERPIFilenamePattern=
          preProcessedPhaseERPIFilenamePattern)
    }
}
