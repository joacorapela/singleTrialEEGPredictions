buildConditionSFPDsInfo <-
function(subjectName, modality, condition, 
                                                 sfpdsInfoFilenamePattern) {
    sfpdsInfoFilename <- sprintf(sfpdsInfoFilenamePattern, subjectName,
                                                           modality,
                                                           condition)
    sfpdsInfo <- readVectorDoubleWithLengthHeader(filename=sfpdsInfoFilename)
    sfpdsInfo <- matrix(sfpdsInfo, ncol=2)
    return(sfpdsInfo)
}
