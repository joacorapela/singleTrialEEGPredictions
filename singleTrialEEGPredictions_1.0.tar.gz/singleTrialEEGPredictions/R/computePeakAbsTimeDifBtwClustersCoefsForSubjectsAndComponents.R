computePeakAbsTimeDifBtwClustersCoefsForSubjectsAndComponents <-
function(sortvar, modality, clusterID1, clusterID2, condition,
                   modelSignificance, srate, lowpassFilterOrder, margin,
                   minPeakTime, onlySignificantPeaks,
                   subjectsAndComponents1, subjectsAndComponents2,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    subjectsNames <- c()
    component1s <- c()
    component2s <- c()
    difs <- c()
    pValues <- c()
    for(i in 1:nrow(subjectsAndComponents1)) {
        subjectName <- subjectsAndComponents1[i, "subjectName"]
        component1 <- subjectsAndComponents1[i, "component"]
        indicesOf1In2 <- 
         which(subjectsAndComponents2[, "subjectName"]==subjectName)
        j <- 1
        while(j<length(indicesOf1In2)) {
            component2 <- subjectsAndComponents2[indicesOf1In2[j], "component"]
            show(sprintf("Processing subject %s component %02d in cluster %02d and component %02d in cluster %02d", 
                         subjectName, 
                         component1, clusterID1, 
                         component2, clusterID2))
            dif <- 
             computePeakAbsTimeDifBtwClustersCoefsForSubjectAndComponent(
              sortvar=sortvar,
              modality=modality,
              clusterID1=clusterID1,
              clusterID2=clusterID2,
              condition=condition,
              subjectName=subjectName,
              component1=component1,
              component2=component2,
              modelSignificance=modelSignificance,
              srate=srate,
              lowpassFilterOrder=lowpassFilterOrder,
              margin=margin,
              minPeakTime=minPeakTime,
              onlySignificantPeaks=onlySignificantPeaks,
              minAndMaxSFPDOfBestPredictionsFilenamePattern=
               minAndMaxSFPDOfBestPredictionsFilenamePattern,
              analyzedDataFilenamePattern=analyzedDataFilenamePattern,
              ...)
            if(!is.null(dif)) {
                subjectsNames <- c(subjectsNames, subjectName)
                component1s <- c(component1s, component1)
                component2s <- c(component2s, component2)
                difs <- c(difs, dif)
            }
            j <- j+1
        }
    }
    if(length(subjectsNames)>0) {
        return(data.frame(subjectName=subjectsNames, 
                           component1=component1s,
                           component2=component2s,
                           dif=difs))
    } else {
        return(data.frame())
    }
}
