selectMinAndMaxSFPDsOfBestPredictionsForConditions <-
function(sortvar, modality, clusterID, conditions, subjectsAndComponents,
                   minSFPDs, maxSFPDs, analyzedDataFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        selectMinAndMaxSFPDsOfBestPredictionsForSubjectsAndComponents(sortvar=sortvar, 
                                                   modality=modality, 
                                                   clusterID=clusterID, 
                                                   condition=condition, 
                                                   subjectsAndComponents=
                                                    subjectsAndComponents,
                                                   minSFPDs=minSFPDs, 
                                                   maxSFPDs=maxSFPDs, 
                                                   analyzedDataFilenamePattern=
                                                    analyzedDataFilenamePattern,
                                                   minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                                    minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
