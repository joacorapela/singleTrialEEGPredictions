getPredictionsCorCoefsAndAveragedBehavioralMeasuresForConditions <-
function(sortvar, modality, clusterID, conditions,
                   errorRatesAndMeanRTsStats,
                   getSubjectBehavioralMeasureCIFunc, 
                   subjectsAndComponents, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    predCorCoefsAndABMs <- list()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        cPredCorCoefsAndABMs <- getPredictionsCorCoefsAndAveragedBehavioralMeasuresForSubjects(
                                 sortvar=sortvar,
                                 modality=modality,
                                 clusterID=clusterID,
                                 condition=condition,
                                 errorRatesAndMeanRTsStats=
                                  errorRatesAndMeanRTsStats,
                                 getSubjectBehavioralMeasureCIFunc=
                                  getSubjectBehavioralMeasureCIFunc,
                                 subjectsAndComponents=subjectsAndComponents,
                                 minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                  minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                 analyzedDataFilenamePattern=
                                  analyzedDataFilenamePattern)
        if(length(cPredCorCoefsAndABMs)>0) {
            predCorCoefsAndABMs <- c(predCorCoefsAndABMs, 
                                      list(cPredCorCoefsAndABMs))
        }
    }
    return(predCorCoefsAndABMs)
}
