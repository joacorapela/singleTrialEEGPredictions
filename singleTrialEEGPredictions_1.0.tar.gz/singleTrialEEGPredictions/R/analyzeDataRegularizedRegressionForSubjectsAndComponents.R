analyzeDataRegularizedRegressionForSubjectsAndComponents <-
function(modality, sortvar, clusterID, condition, 
                    subjectsAndComponents,
                    preProcessedPhaseERPIFilenamePattern, 
                    analyzedConditionsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, interactions, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, computeCoefsCIs, maxIter, convergenceTol,
                    nResamplesCoefs, nResamplesPredictions, 
                    confCIs) {
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
        analyzeDataRegularizedRegressionForSubjectAndComponent(
         modality=modality, 
         sortvar=sortvar, 
         clusterID=clusterID, 
         condition=condition, 
         subjectName=subjectName,
         component=component,
         preProcessedPhaseERPIFilenamePattern=preProcessedPhaseERPIFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         interactions=interactions,
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, computeCoefsCIs=computeCoefsCIs,
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nResamplesCoefs=nResamplesCoefs,
         nResamplesPredictions=nResamplesPredictions, 
         confCIs=confCIs)
    }
}
