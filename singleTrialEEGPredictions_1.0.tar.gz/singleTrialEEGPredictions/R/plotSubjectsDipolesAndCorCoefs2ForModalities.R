plotSubjectsDipolesAndCorCoefs2ForModalities <-
function(sortvar, modalities, conditions, subjectsNames, clustersIDs, 
                   modelSignificance, scaleLimit, pointSize,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   dipfitInfoFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotSubjectsDipolesAndCorCoefs2ForConditions(
         sortvar=sortvar, 
         modality=modality, 
         conditions=conditions, 
         subjectsNames=subjectsNames,
         clustersIDs=clustersIDs, 
         modelSignificance=modelSignificance,
         scaleLimit=scaleLimit,
         pointSize=pointSize,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         dipfitInfoFilenamePattern=dipfitInfoFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, 
         height=height, ...)
    }
}
