preProcessPhaseERPImagesForClusters <-
function(sortvar, 
           modality, 
           clustersIDs, 
           conditions, 
           srate,
           clipFrom, clipTo,
           alignmentSignificance,
           plotSteps,
           averageTrialsWinSize,
           plotsFilenamePattern,
           width, height,
           xlim, zlim,
           scFilenamePattern,
           phaseERPImageFilenamePattern,
           preProcessedPhaseERPIFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <- getSubjectsAndComponentsInCluster(clusterID, 
                                                                    scFilename)
        preProcessPhaseERPImagesForConditions(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         conditions=conditions,
         subjectsAndComponents=subjectsAndComponents,
         srate=srate,
         clipFrom=clipFrom,
         clipTo=clipTo,
         alignmentSignificance=alignmentSignificance,
         plotSteps=plotSteps,
         averageTrialsWinSize=averageTrialsWinSize,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         xlim=xlim, zlim=zlim, 
         phaseERPImageFilenamePattern=phaseERPImageFilenamePattern,
         preProcessedPhaseERPIFilenamePattern=
          preProcessedPhaseERPIFilenamePattern)
    }
}
