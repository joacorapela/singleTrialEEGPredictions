plotPredictionsCorCoefsVsMinSFPDs2ForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition, minSFPDs, maxSFPD,
                   nResamples, modelSignificance, rConf,
                   subjectName, 
                   component,
                   analyzedConditionsFilenamePattern,
                   plotsFilenamePattern,
                   xlab,
                   ylab="Correlation Coefficient",
                   main="", 
                   ...) {
    i <- 1
    predSFPDurCorsCIs <- c()
    for(minSFPD in minSFPDs) {
        analyzedConditionFilename <- sprintf(analyzedConditionsFilenamePattern,
                                              clusterID,
                                              condition,
                                              sortvar,
                                              modality,
                                              subjectName,
                                              component,
                                              minSFPD,
                                              maxSFPD)
        show(sprintf("Processing minSFPD %d", minSFPD))
        analyzedCondition <- get(load(analyzedConditionFilename))
        if(!is.null(analyzedCondition$predSFPDurCorCI)) {
            if(is.nan(modelSignificance)) {
                predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, 
                                            analyzedCondition$predSFPDurCorCI) 
            } else {
                if(analyzedCondition$lrtRes$pValue<modelSignificance) {
                    predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, 
                                                analyzedCondition$
                                                 predSFPDurCorCI) 
                } else {
                    predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, c(0, 0, 0))
                }
            }
        } else {
            predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, c(0, 0, 0))
        }
        i <- i+1
    }
    if(nrow(predSFPDurCorsCIs)>1) {
        plotCIsForCategories(categoriesNames=sprintf("%d", minSFPDs), 
                              cis=predSFPDurCorsCIs, 
                              xlab=xlab, ylab=ylab, main=main, ...)
    } else {
        print(getEmptyPlot())
    }
    plotFilename <- sprintf(plotsFilenamePattern, 
                             maxSFPD,
                             modality, 
                             sortvar, 
                             clusterID, 
                             condition,
                             subjectName,
                             component)
    ggsave(filename=plotFilename)
}
