getANOVADataFrame2ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, modelSignificance,
                   getANOVADataForSubjectFunc,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    dataFrame <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        mDataFrame <- getANOVADataFrame2ForClusters(
                   sortvar=sortvar,
                   modality=modality,
                   clustersIDs=clustersIDs,
                   conditions=conditions,
                   modelSignificance=modelSignificance,
                   getANOVADataForSubjectFunc=getANOVADataForSubjectFunc,
                   scFilenamePattern=scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern=
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        if(length(mDataFrame)>0) {
            mDataFrame["modality"] <- modality
            dataFrame <- rbind(dataFrame, mDataFrame)
        }
    }
    dataFrame$modality  <- as.factor(dataFrame$modality)
    dataFrame$clusterID <- as.factor(dataFrame$clusterID)
    dataFrame$condition <- as.factor(dataFrame$condition)
    dataFrame$subject   <- as.factor(dataFrame$subject)
    return(dataFrame)
}
