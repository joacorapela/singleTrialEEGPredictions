saveITCsPeaksForClusters <-
function(sortvar, 
                                      modality, 
                                      clustersIDs, 
                                      conditions,
                                      noctave, nvoice, nCycles,
                                      itcsFilenamePattern, 
                                      itcsPeaksFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        saveITCsPeaksForConditions(sortvar=sortvar,
                                    modality=modality,
                                    clusterID=clusterID,
                                    conditions=conditions,
                                    noctave=noctave, nvoice=nvoice, nCycles=nCycles,
                                    itcsFilenamePattern=
                                     itcsFilenamePattern, 
                                    itcsPeaksFilenamePattern=
                                     itcsPeaksFilenamePattern)
    }
}
