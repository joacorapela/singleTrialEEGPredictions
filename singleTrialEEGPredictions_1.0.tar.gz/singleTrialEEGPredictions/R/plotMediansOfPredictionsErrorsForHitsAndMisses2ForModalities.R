plotMediansOfPredictionsErrorsForHitsAndMisses2ForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                   getStatsDifAnnotationFunction,
                   rtsForSTDsInfo,
                   dfpdsForSTDsInfo,
                   maxRT, 
                   maxDFPD,
                   nResamples, conf,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotMediansOfPredictionsErrorsForHitsAndMisses2ForClusters(
         sortvar=sortvar, 
         modality=modality,
         clustersIDs=clustersIDs, 
         conditions=conditions,
         getStatsDifAnnotationFunction=getStatsDifAnnotationFunction,
         rtsForSTDsInfo=rtsForSTDsInfo,
         dfpdsForSTDsInfo=dfpdsForSTDsInfo,
         maxRT=maxRT,
         maxDFPD=maxDFPD,
         nResamples=nResamples,
         conf=conf,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         ...)
    }
}
