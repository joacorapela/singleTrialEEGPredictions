saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForClusters <-
function(sortvar, modality, clustersIDs, conditions, nResamples, conf,
                   modelSignificance, errorRatesAndMeanRTsStats, 
                   getSubjectBehavioralMeasureCIFunc, 
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   statsFilenamePattern, ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID,
                                            scFilename=scFilename)
        saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForConditions(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         conditions=conditions,
         nResamples=nResamples,  
         conf=conf,
         modelSignificance=modelSignificance,
         errorRatesAndMeanRTsStats=errorRatesAndMeanRTsStats,
         getSubjectBehavioralMeasureCIFunc=getSubjectBehavioralMeasureCIFunc,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         statsFilenamePattern=statsFilenamePattern,
         ...)
    }
}
