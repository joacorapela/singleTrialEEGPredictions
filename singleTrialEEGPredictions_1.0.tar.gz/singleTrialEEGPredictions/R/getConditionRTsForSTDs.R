getConditionRTsForSTDs <-
function(condition, rtsForSTDsInfoForConditions) {
    for(i in 1:length(rtsForSTDsInfoForConditions)) {
        if(rtsForSTDsInfoForConditions[[i]]$condition==condition) {
            return(rtsForSTDsInfoForConditions[[i]]$rtsForSTDsInfo)
        }
    }
    stop(sprintf("Condition %s not found", condition))
}
