getDFStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasuresForModalities <-
function(sortvar, modalities, clustersIDs, conditions, filterFunc,
                   getDFStatsForConditionFunc, statsFilenamePattern) {
    dataFrame <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        mDataFrame <- 
         getDFStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasuresForClusters(
          sortvar=sortvar, 
          modality=modality, 
          clustersIDs=clustersIDs,
          conditions=conditions,
          filterFunc=filterFunc,
          getDFStatsForConditionFunc=getDFStatsForConditionFunc,
          statsFilenamePattern=statsFilenamePattern)
        if(length(mDataFrame)>0) {
            mDataFrame["modality"] <- modality
            dataFrame <- rbind(dataFrame, mDataFrame)
        }
    }
    if(length(dataFrame)>0) {
        dataFrame$modality  <- as.factor(dataFrame$modality)
        dataFrame$clusterID <- as.factor(dataFrame$clusterID)
        dataFrame$condition <- as.factor(dataFrame$condition)
    }
    return(dataFrame)
}
