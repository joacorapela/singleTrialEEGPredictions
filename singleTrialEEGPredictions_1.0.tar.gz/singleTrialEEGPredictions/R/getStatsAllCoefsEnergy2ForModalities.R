getStatsAllCoefsEnergy2ForModalities <-
function(sortvar, modalities, conditions, clustersIDs, modelSignificance,
                   nResamples, ciConf,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    answer <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        stats <- getStatsAllCoefsEnergy2ForConditions(
                        sortvar=sortvar,
                        modality=modality,
                        conditions=conditions,
                        clustersIDs=clustersIDs,
                        modelSignificance=modelSignificance,
                        nResamples=nResamples,
                        ciConf=ciConf,
                        scFilenamePattern=scFilenamePattern,
                        minAndMaxSFPDOfBestPredictionsFilenamePattern=
                         minAndMaxSFPDOfBestPredictionsFilenamePattern,
                        analyzedDataFilenamePattern=
                         analyzedDataFilenamePattern)
        answer <- c(answer, list(list(modality=modality,
                                       stats=stats)))
    }
    return(answer)
}
