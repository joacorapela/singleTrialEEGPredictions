computeDotProductBtwConditionsCoefsForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition1, condition2,
                   subjectName, component, significance,
                   nResamples, minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
if(subjectName=="av118a" && component==3) {
    browser()
}
    c1MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
              clusterID, condition1, sortvar, modality, subjectName, component)
    res <- readLines(c1MinAndMaxSFPDOfBestPredictionsFilename)
    c1MinSFPD <- as.integer(res[1])
    c1MaxSFPD <- as.integer(res[2])
    c2MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
              clusterID, condition2, sortvar, modality, subjectName, component)
    res <- readLines(c2MinAndMaxSFPDOfBestPredictionsFilename)
    c2MinSFPD <- as.integer(res[1])
    c2MaxSFPD <- as.integer(res[2])
    c1AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID,
                                       clusterID,
                                       condition1,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component,
                                       c1MinSFPD,
                                       c1MaxSFPD)
    c2AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID,
                                       clusterID,
                                       condition2,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component,
                                       c2MinSFPD,
                                       c2MaxSFPD)
    c1AnalyzedData <- get(load(c1AnalyzedDataFilename))
    c2AnalyzedData <- get(load(c2AnalyzedDataFilename))

    if(!is.null(c1AnalyzedData$coefsCIs)||!is.null(c2AnalyzedData$coefsCIs)) {
            res <- computeDotProductBtwConditionsCoefs(
                    times1=c1AnalyzedData$times,
                    condition1Coefs=c1AnalyzedData$coefsCIs[-1,1], 
                    times2=c2AnalyzedData$times,
                    condition2Coefs=c2AnalyzedData$coefsCIs[-1,1],
                    nResamples=nResamples)
            dotProduct <- res$dotProduct
            pValue <- res$pValue
    } else {
        dotProduct <- NaN
        pValue <- NaN
    }
    return(c(dotProduct, pValue))
}
