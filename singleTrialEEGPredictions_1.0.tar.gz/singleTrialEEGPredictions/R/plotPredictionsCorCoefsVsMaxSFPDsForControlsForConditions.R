plotPredictionsCorCoefsVsMaxSFPDsForControlsForConditions <-
function(sortvar, modality, clusterID, conditions, minSFPD, maxSFPDs,
                   nResamples, modelSignificance, ciConf,
                   subjectsAndComponents, 
                   coefsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotPredictionsCorCoefsVsMaxSFPDsForControlsForSubjectsAndComponents(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         minSFPD=minSFPD,
         maxSFPDs=maxSFPDs,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         ciConf=ciConf,
         subjectsAndComponents=subjectsAndComponents,
         coefsFilenamePattern=coefsFilenamePattern, 
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab,
         ylab=ylab,
         main=main,
         ...)
    }
}
