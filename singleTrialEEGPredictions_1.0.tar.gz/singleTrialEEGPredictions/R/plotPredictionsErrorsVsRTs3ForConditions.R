plotPredictionsErrorsVsRTs3ForConditions <-
function(sortvar, modality, clusterID, conditions,
                   getStatsCorCoefAnnotationFunction,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, 
                   maxDFPD,
                   nResamples, conf,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotPredictionsErrorsVsRTs3ForCondition(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         getStatsCorCoefAnnotationFunction=getStatsCorCoefAnnotationFunction,
         dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
         rtsInfo=rtsInfo,
         dfpdsInfo=dfpdsInfo,
         maxRT=maxRT, 
         maxDFPD=maxDFPD,
         nResamples=nResamples, conf=conf,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height, ...)
    }
}
