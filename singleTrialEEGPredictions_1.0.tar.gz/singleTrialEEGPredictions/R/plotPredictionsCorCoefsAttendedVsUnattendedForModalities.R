plotPredictionsCorCoefsAttendedVsUnattendedForModalities <-
function(sortvar, modalities, clustersIDs, attCondition, unattCondition,
                   minSFPD, maxSFPD,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   scFilenamePattern, 
                   analyzedDataFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(modality in modalities) {
        modalityPredictionsCorCoefs <- plotPredictionsCorCoefsAttendedVsUnattendedForClusters(
                        sortvar=sortvar,
                        modality=modality,
                        clustersIDs=clustersIDs,
                        attCondition=attCondition,
                        unattCondition=unattCondition,
                        minSFPD=minSFPD,
                        maxSFPD=maxSFPD,
                        significance=significance,
                        nResamples=nResamples,
                        ciConf=ciConf,
                        annotationPattern=annotationPattern,
                        scFilenamePattern=scFilenamePattern,
                        analyzedDataFilenamePattern=
                         analyzedDataFilenamePattern,
                        plotFilenamePattern=plotFilenamePattern,
                        ...)
    }
}
