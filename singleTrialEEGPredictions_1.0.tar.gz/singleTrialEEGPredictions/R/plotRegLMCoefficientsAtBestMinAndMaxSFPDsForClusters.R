plotRegLMCoefficientsAtBestMinAndMaxSFPDsForClusters <-
function(sortvar, 
           modality, 
           clustersIDs,
           conditions,
           unstandardize,
           modelSignificance,
           subjectsAndComponents,
           scFilenamePattern,
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern,
           plotsFilenamePattern,
           ...) {
    if(is.na(subjectsAndComponents[1]) && is.na(scFilenamePattern[1])) {
        stop("One of subjectsAndComponents or scFilenamePattern should be provided")
    }
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %s", clusterID))
        if(is.null(subjectsAndComponents)) {
            scFilename <- sprintf(scFilenamePattern, clusterID)
            if(is.null(scFilename)) {
                stop("arguments subjectsAndComponents or scFilenamePattern should be provided")
            }
            subjectsAndComponentsInCluster <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                                scFilename=scFilename)
        } else {
            subjectsAndComponentsInCluster <- subjectsAndComponents
        }
        plotRegLMCoefficientsAtBestMinAndMaxSFPDsForConditions(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID, 
         conditions=conditions,
         unstandardize=unstandardize,
         modelSignificance=modelSignificance,
         subjectsAndComponents=subjectsAndComponentsInCluster,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         ...)
    }
}
