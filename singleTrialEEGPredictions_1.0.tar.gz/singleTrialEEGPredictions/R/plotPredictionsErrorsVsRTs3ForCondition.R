plotPredictionsErrorsVsRTs3ForCondition <-
function(sortvar, modality, clusterID, condition,
                   getStatsCorCoefAnnotationFunction,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD,
                   nResamples, conf,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   plotsFilenamePattern, 
                   width, height, ...) {
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, 
                  clusterID, clusterID, condition, sortvar, modality, 
                  subjectName, component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        if(!is.na(minSFPD) && !is.na(maxSFPD)) {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                             clusterID,
                                             clusterID,
                                             condition,
                                             sortvar,
                                             modality,
                                             subjectName,
                                             component,
                                             minSFPD,
                                             maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))
            if(!is.null(analyzedData$data)) {
                subsetSTDsDeviantsDF <- 
                 buildSubjectAndComponentSingleTrialANOVADF(
                  subjectName=subjectName,
                  modality=modality,
                  condition=condition,
                  analyzedData=analyzedData, 
                  rtsInfo=rtsInfo,
                  dfpdsInfo=dfpdsInfo,
                  dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                  maxRT=maxRT,
                  maxSTD_D_delay=maxSTD_D_delay,
                  maxDFPD=maxDFPD)
                plotFilename <- sprintf(plotsFilenamePattern, 
                                         modality, 
                                         sortvar, 
                                         clusterID, 
                                         condition,
                                         subjectName,
                                         component)

                trellis.device("postscript", color=TRUE, width=width, 
                               height=height, onefile=FALSE, horizontal=FALSE, 
                               file=plotFilename)
                trellis.par.set(theme=canonical.theme("X11"))
                if(!is.null(analyzedData$predictions)) {
                    plotPredictionsErrorsVsRTs3(
                     predictionErrors=subsetSTDsDeviantsDF$predictionError,
                     rts=subsetSTDsDeviantsDF$rt,
                     dfpds=subsetSTDsDeviantsDF$dfpd,
                     maxRT=maxRT,
                     maxDFPD=maxDFPD,
                     nResamples=nResamples,
                     conf=conf,
                     getStatsCorCoefAnnotationFunction=
                      getStatsCorCoefAnnotationFunction,
                     ...)
                }
                dev.off()
            }
        }
    }
}
