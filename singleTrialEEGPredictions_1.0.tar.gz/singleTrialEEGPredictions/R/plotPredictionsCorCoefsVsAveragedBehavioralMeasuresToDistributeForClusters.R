plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForClusters <-
function(sortvar, modality, clustersIDs, conditions, 
                   modelSignificance,
                   annotationPattern, 
                   scFilenamePattern, 
                   analyzedConditionsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   behavioralMeasuresFilenamePattern,
                   plotsFilenamePattern,
                   xCorCoefAnnotation, yCorCoefAnnotation, 
                   hjust, vjust,
                   sizeLabels, sizeAnnotations, xlab, ylab, main, 
                   width, height, ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForConditions(
         sortvar=sortvar, 
         modality=modality, 
         clusterID=clusterID, 
         conditions=conditions, 
         modelSignificance=modelSignificance,
         annotationPattern=annotationPattern, 
         subjectsAndComponents=subjectsAndComponents,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern, 
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         behavioralMeasuresFilenamePattern=behavioralMeasuresFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         xCorCoefAnnotation=xCorCoefAnnotation, 
         yCorCoefAnnotation=yCorCoefAnnotation, 
         hjust=hjust, vjust=vjust,
         sizeLabels=sizeLabels, 
         sizeAnnotations=sizeAnnotations, 
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         width=width, 
         height=height, ...)
    }
}
