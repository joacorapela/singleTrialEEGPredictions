plotMaxSFPDsForTwoConditionsForClusters <-
function(sortvar, modality, clustersIDs, condition1, condition2, 
                   nResamples, ciConf, annotationPattern, 
                   scFilenamePattern, 
                   maxSFPDsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        clusterCorCoefs <- 
         plotMaxSFPDsForTwoConditionsForSubjectsAndComponents(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          condition1=condition1,
          condition2=condition2,
          nResamples=nResamples,
          ciConf=ciConf,
          annotationPattern=annotationPattern,
          subjectsAndComponents=subjectsAndComponents,
          maxSFPDsFilenamePattern=
           maxSFPDsFilenamePattern,
          plotFilenamePattern=plotFilenamePattern,
          ...)
    }
}
