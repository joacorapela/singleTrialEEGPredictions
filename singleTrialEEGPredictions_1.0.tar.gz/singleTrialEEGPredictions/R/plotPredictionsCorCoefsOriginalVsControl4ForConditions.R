plotPredictionsCorCoefsOriginalVsControl4ForConditions <-
function(sortvar, modality, clusterID, conditions,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   subjectsAndComponents,
                   bootPairedDifferencesFunction, 
                   oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   controlCorCoefsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(condition in conditions) {
        conditionPredictionsCorCoefs <- 
         plotPredictionsCorCoefsOriginalVsControl4ForSubjects(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          condition=condition,
          significance=significance,
          nResamples=nResamples,
          ciConf=ciConf,
          annotationPattern=annotationPattern,
          subjectsAndComponents=subjectsAndComponents,
          bootPairedDifferencesFunction=bootPairedDifferencesFunction,
          oMinAndMaxSFPDOfBestPredictionsFilenamePattern=
           oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
          cMinAndMaxSFPDOfBestPredictionsFilenamePattern=
           cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
          analyzedDataFilenamePattern=analyzedDataFilenamePattern,
          controlCorCoefsFilenamePattern=controlCorCoefsFilenamePattern,
          plotFilenamePattern=plotFilenamePattern,
          ...)
    }
}
