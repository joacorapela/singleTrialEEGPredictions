plotPredictionsVsSFPDs3ForConditions <-
function(sortvar, modality, clusterID, conditions, 
                   adjustedPValuesDF,
                   corCoefAnnotationFunction,
                   subjectsAndComponents, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotPredictionsVsSFPDs3ForSubjects(sortvar=sortvar, 
                                           modality=modality,
                                           clusterID=clusterID, 
                                           condition=condition,
                                           adjustedPValuesDF=adjustedPValuesDF,
                                           corCoefAnnotationFunction=
                                            corCoefAnnotationFunction,
                                           subjectsAndComponents=
                                            subjectsAndComponents,
                                           minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                            minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                           analyzedDataFilenamePattern=
                                            analyzedDataFilenamePattern,
                                           plotsFilenamePattern=
                                            plotsFilenamePattern,
                                           width=width,
                                           height=height,
                                           ...)
    }
}
