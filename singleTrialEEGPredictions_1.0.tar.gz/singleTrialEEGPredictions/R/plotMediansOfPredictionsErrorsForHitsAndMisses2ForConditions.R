plotMediansOfPredictionsErrorsForHitsAndMisses2ForConditions <-
function(sortvar, modality, clusterID, conditions,
                   getStatsDifAnnotationFunction,
                   rtsForSTDsInfo,
                   dfpdsForSTDsInfo,
                   maxRT, 
                   maxDFPD,
                   nResamples,
                   conf,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotMediansOfPredictionsErrorsForHitsAndMisses2ForSubjects(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         getStatsDifAnnotationFunction=getStatsDifAnnotationFunction,
         rtsForSTDsInfo=rtsForSTDsInfo,
         dfpdsForSTDsInfo=dfpdsForSTDsInfo,
         maxRT=maxRT,
         maxDFPD=maxDFPD,
         nResamples=nResamples,
         conf=conf,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         ...)
    }
}
