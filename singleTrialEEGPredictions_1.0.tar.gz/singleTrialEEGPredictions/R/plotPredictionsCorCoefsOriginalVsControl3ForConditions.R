plotPredictionsCorCoefsOriginalVsControl3ForConditions <-
function(sortvar, modality, clusterID, conditions, minSFPD, maxSFPD,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   subjectsAndComponents=subjectsAndComponents,
                   analyzedDataFilenamePattern,
                   controlCorCoefsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(condition in conditions) {
        conditionPredictionsCorCoefs <- plotPredictionsCorCoefsOriginalVsControl3ForSubjects(
                                  sortvar=sortvar,
                                  modality=modality,
                                  clusterID=clusterID,
                                  condition=condition,
                                  minSFPD=minSFPD,
                                  maxSFPD=maxSFPD,
                                  significance=significance,
                                  nResamples=nResamples,
                                  ciConf=ciConf,
                                  annotationPattern=annotationPattern,
                                  subjectsAndComponents=subjectsAndComponents,
                                  analyzedDataFilenamePattern=
                                   analyzedDataFilenamePattern,
                                  controlCorCoefsFilenamePattern=
                                   controlCorCoefsFilenamePattern,
                                  plotFilenamePattern=plotFilenamePattern,
                                  ...)
    }
}
