getPredictionsAndSFPDsBySubjectForConditions <-
function(sortvar, subject, modality, clusterID, conditions, 
                   modelSignificance,
                   components,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        cDataSet <- getPredictionsAndSFPDsBySubjectForComponents(
                     sortvar=sortvar,
                     subject=subject,
                     modality=modality,
                     clusterID=clusterID,
                     condition=condition,
                     components=components,
                     modelSignificance=modelSignificance, 
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, cDataSet)
    }
    return(datasets)
}
