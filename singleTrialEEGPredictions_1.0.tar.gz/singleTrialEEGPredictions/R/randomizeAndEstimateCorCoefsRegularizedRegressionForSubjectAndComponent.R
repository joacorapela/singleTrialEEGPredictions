randomizeAndEstimateCorCoefsRegularizedRegressionForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition, 
                   subjectName,
                   component,
                   minSFPDs, maxSFPDs, lambda, order, scaleData, 
                   nGroups, 
                   a0, b0, c0, d0, maxIter, convergenceTol, nRandomizations,
                   clipFrom, clipTo, srate, 
                   stdsNextDsLatenciesInfo,
                   stdsNextCuesLatenciesInfo,
                   stdsNextEOBsLatenciesInfo,
                   phaseERPImageFilenamePattern, 
                   timesPPPhaseERPIFilenamePattern,
                   corCoefsFilenamePattern, 
                   plotSteps,
                   averageTrialsWinSize,
                   plotsFilenamePattern,
                   width, height) {
    preProcessedPhaseERPIFilename <- 
     sprintf(phaseERPImageFilenamePattern, 
              clusterID,
              condition,
              sortvar,
              modality,
              subjectName,
              component)
    preProcessedPhaseERPI <- get(load(preProcessedPhaseERPIFilename))
    for(minSFPD in minSFPDs) {
        i <- 1
        while(i<=length(maxSFPDs) && 
               maxSFPDs[i]<=max(preProcessedPhaseERPI$sfpds)) {
            if(maxSFPDs[i]<minSFPD) {
                next
            }
            show(sprintf("Processing %s%02d: minSFPD %d, maxSFPD %d",
                         subjectName, component, minSFPD, maxSFPDs[i]))
            maxSFPD <- maxSFPDs[i]
            corCoefsFilename <- 
             sprintf(corCoefsFilenamePattern, clusterID, condition,
                                              sortvar, modality, subjectName, 
                                              component, minSFPD, maxSFPD)
            corCoefs <- randomizeAndEstimateCorCoefsRegularizedRegression(
                         sortvar=sortvar, 
                         modality=modality, 
                         clusterID=clusterID, 
                         condition=condition, 
                         subjectName=subjectName,
                         component=component,
                         minSFPD=minSFPD,
                         maxSFPD=maxSFPD,
                         lambda=lambda,
                         order=order, 
                         scaleData=scaleData,
                         nGroups=nGroups, 
                         a0=a0, b0=b0, c0=c0, d0=d0, 
                         maxIter=maxIter,
                         convergenceTol=convergenceTol,
                         nRandomizations=nRandomizations,
                         clipFrom=clipFrom, clipTo=clipTo, 
                         srate=srate,
                         stdsNextDsLatenciesInfo=stdsNextDsLatenciesInfo,
                         stdsNextCuesLatenciesInfo=stdsNextCuesLatenciesInfo,
                         stdsNextEOBsLatenciesInfo=stdsNextEOBsLatenciesInfo,
                         phaseERPImageFilenamePattern=
                          phaseERPImageFilenamePattern,
                         timesPPPhaseERPIFilenamePattern=
                          timesPPPhaseERPIFilenamePattern,
                         corCoefsFilenamePattern=corCoefsFilenamePattern,
                         plotSteps=plotSteps,            
                         averageTrialsWinSize=averageTrialsWinSize,
                         plotsFilenamePattern=plotsFilenamePattern, 
                         width=width, height=height)
            save(corCoefs, file=corCoefsFilename)
            i <- i+1
        }
    }
}
