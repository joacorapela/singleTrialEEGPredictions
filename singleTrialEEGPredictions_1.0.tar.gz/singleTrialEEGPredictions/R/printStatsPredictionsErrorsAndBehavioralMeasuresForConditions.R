printStatsPredictionsErrorsAndBehavioralMeasuresForConditions <-
function(sortvar, modality, clusterID, conditions,
                    sFPStatsForConditions,
                    dFPStats, 
                    modelSignificance,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                    analyzedDataFilenamePattern,
                    filterSFPStatsFunc, 
                    filterDFPStatsFunc,
                    printUnselectedSFPStats,
                    printUnselectedDFPStats,
                    printSFPAndDFPStatsFunc,
                    printSFPStatsFunc,
                    con) {
    for(condition in conditions) {
        sFPStatsForSubjects <-
         getItemInAVShiftList(listOfItems=sFPStatsForConditions,
                               listFieldName="stats",
                               keyFieldNames=c("condition"),
                               keyFieldValues=c(condition))
        if(length(sFPStatsForSubjects)>0) {
            printStatsPredictionsErrorsAndBehavioralMeasuresForSubjects( 
            sortvar=sortvar,
            modality=modality,
            clusterID=clusterID,
            condition=condition, 
            sFPStatsForSubjects=sFPStatsForSubjects,
            dFPStats=dFPStats,
            modelSignificance=modelSignificance,
            minAndMaxSFPDOfBestPredictionsFilenamePattern=
            minAndMaxSFPDOfBestPredictionsFilenamePattern,
            analyzedDataFilenamePattern=analyzedDataFilenamePattern,
            filterSFPStatsFunc=filterSFPStatsFunc,
            filterDFPStatsFunc=filterDFPStatsFunc,
            printUnselectedSFPStats=printUnselectedSFPStats,
            printUnselectedDFPStats=printUnselectedDFPStats,
            printSFPAndDFPStatsFunc=printSFPAndDFPStatsFunc,
            printSFPStatsFunc=printSFPStatsFunc,
            con=con)
        }
    }
}
