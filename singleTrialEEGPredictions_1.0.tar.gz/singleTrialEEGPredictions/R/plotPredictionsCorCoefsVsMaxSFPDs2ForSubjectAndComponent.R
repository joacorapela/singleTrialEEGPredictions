plotPredictionsCorCoefsVsMaxSFPDs2ForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition, maxSFPDs,
                   nResamples, modelSignificance, rConf,
                   subjectName, 
                   component,
                   analyzedConditionsFilenamePattern,
                   plotsFilenamePattern,
                   xlab,
                   ylab="Correlation Coefficient",
                   main="", 
                   ...) {
    i <- 1
    predSFPDurCorsCIs <- c()
    while(i<=length(maxSFPDs)) {
        maxSFPD <- maxSFPDs[i]
        analyzedConditionFilename <- sprintf(analyzedConditionsFilenamePattern,
                                              clusterID,
                                              clusterID,
                                              condition,
                                              sortvar,
                                              modality,
                                              subjectName,
                                              component,
                                              maxSFPD)
        if(!file.exists(analyzedConditionFilename)) {
            break
        }
        show(sprintf("Processing maxSFPD %d", maxSFPDs[i]))
        analyzedCondition <- get(load(analyzedConditionFilename))
        if(!is.null(analyzedCondition$predSFPDurCorCI)) {
            if(is.nan(modelSignificance)) {
                predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, 
                                            analyzedCondition$predSFPDurCorCI) 
            } else {
                if(analyzedCondition$lrtRes$pValue<modelSignificance) {
                    predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, 
                                                analyzedCondition$
                                                 predSFPDurCorCI) 
                } else {
                    predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, c(0, 0, 0))
                }
            }
        } else {
            predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, c(0, 0, 0))
        }
        i <- i+1
    }
    usedMaxSFPDs <- maxSFPDs[1:(i-1)]
    if(nrow(predSFPDurCorsCIs)>1) {
        plotCorCoefsCIsVsMaxSFPDs(maxSFPDs=usedMaxSFPDs/1000, 
                                   cis=predSFPDurCorsCIs, 
                                   xlab=xlab, ylab=ylab, main=main, ...)
    } else {
        print(getEmptyPlot())
    }
    plotFilename <- sprintf(plotsFilenamePattern, 
                             clusterID,
                             modality, 
                             sortvar, 
                             clusterID, 
                             condition,
                             subjectName,
                             component)
    ggsave(filename=plotFilename)
}
