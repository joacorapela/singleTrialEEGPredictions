getSubjectAndConditionDFPDsForSTDsInfo <-
function(subjectName, 
                                                    modality,
                                                    condition, 
                                                    dfpdsForSTDsInfo) {
    for(i in 1:length(dfpdsForSTDsInfo)) {
        if(dfpdsForSTDsInfo[[i]]$subjectName==subjectName) {
            dfpdsForSTDsInfoForModalities <- 
             dfpdsForSTDsInfo[[i]]$dfpdsForSTDsInfo
            return(getModalityDFPDsForSTDs(modality=modality,
                                            condition=condition,
                                            dfpdsForSTDsInfoForModalities=
                                             dfpdsForSTDsInfoForModalities))
        }
    }
    stop(sprintf("Subject %s not found", subjectName))
}
