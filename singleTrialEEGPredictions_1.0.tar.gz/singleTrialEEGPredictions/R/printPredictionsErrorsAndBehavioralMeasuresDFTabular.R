printPredictionsErrorsAndBehavioralMeasuresDFTabular <-
function(df, printDFRowFunc, 
              printTabularHeaderFunc,
              printTabularFooterFunc, 
              printSubjectSeparatorFunc,
              printFilename) {
    con <- file(printFilename, open="wt")
    printTabularHeaderFunc(con=con)
    printPredictionsErrorsAndBehavioralMeasuresTabularRows(
     df=df, 
     printDFRowFunc=printDFRowFunc,
     printSubjectSeparatorFunc=printSubjectSeparatorFunc,
     con=con)
    printTabularFooterFunc(con=con)
    close(con)
}
