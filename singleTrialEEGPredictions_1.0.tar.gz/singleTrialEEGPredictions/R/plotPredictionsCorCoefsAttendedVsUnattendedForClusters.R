plotPredictionsCorCoefsAttendedVsUnattendedForClusters <-
function(sortvar, modality, clustersIDs, attCondition, unattCondition, 
                   minSFPD, maxSFPD,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   scFilenamePattern, 
                   analyzedDataFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        clusterCorCoefs <- 
         plotPredictionsCorCoefsAttendedVsUnattendedForSubjectsAndComponents(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          attCondition=attCondition,
          unattCondition=unattCondition,
          minSFPD=minSFPD,
          maxSFPD=maxSFPD,
          significance=significance,
          nResamples=nResamples,
          ciConf=ciConf,
          annotationPattern=annotationPattern,
          subjectsAndComponents=subjectsAndComponents,
          analyzedDataFilenamePattern=
           analyzedDataFilenamePattern,
          plotFilenamePattern=plotFilenamePattern,
          ...)
    }
}
