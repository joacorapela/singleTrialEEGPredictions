selectMinAndMaxSFPDsOfBestPredictionsForControlsForConditions <-
function(sortvar, modality, clusterID, conditions, subjectsAndComponents,
                   minSFPDs, maxSFPDs, corCoefsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        selectMinAndMaxSFPDsOfBestPredictionsForControlsForSubjectsAndComponents(sortvar=sortvar, 
                                                   modality=modality, 
                                                   clusterID=clusterID, 
                                                   condition=condition, 
                                                   subjectsAndComponents=
                                                    subjectsAndComponents,
                                                   minSFPDs=minSFPDs, 
                                                   maxSFPDs=maxSFPDs, 
                                                   corCoefsFilenamePattern=
                                                    corCoefsFilenamePattern,
                                                   minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                                    minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
