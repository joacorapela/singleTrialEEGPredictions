getSubjectModalityAndConditionSFPDsInfo <-
function(subjectName, 
                                                    modality, 
                                                    condition,
                                                    sfpdsInfoForSubjects) {
    for(i in 1:length(sfpdsInfoForSubjects)) {
        if(sfpdsInfoForSubjects[[i]]$subjectName==subjectName) {
            sfpdsInfoForModalities <- sfpdsInfoForSubjects[[i]]$sfpdsInfo
            return(getModalityAndConditionSFPDsInfo(modality=modality,
                                                    condition=condition,
                                                    sfpdsInfoForModalities=
                                                     sfpdsInfoForModalities))
        }
    }
    stop(sprintf("Subject %s not found", subjectName))
}
