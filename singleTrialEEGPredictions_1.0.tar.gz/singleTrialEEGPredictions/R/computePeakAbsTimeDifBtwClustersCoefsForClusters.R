computePeakAbsTimeDifBtwClustersCoefsForClusters <-
function(sortvar, modality, clustersIDs1, clustersIDs2, conditions,
                   modelSignificance, srate, lowpassFilterOrder, margin,
                   minPeakTime, onlySignificantPeaks,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(clusterID1 in clustersIDs1) {
        show(sprintf("Processing cluster1 %02d", clusterID1))
        for(clusterID2 in clustersIDs2) {
            show(sprintf("Processing cluster2 %02d", clusterID2))
            scFilename1 <- sprintf(scFilenamePattern, clusterID1, sortvar)
            subjectsAndComponents1 <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID1, 
                                                scFilename=scFilename1)
            scFilename2 <- sprintf(scFilenamePattern, clusterID2, sortvar)
            subjectsAndComponents2 <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID2, 
                                                scFilename=scFilename2)
            res <- 
             computePeakAbsTimeDifBtwClustersCoefsForConditions(
              sortvar=sortvar,
              modality=modality,
              clusterID1=clusterID1,
              clusterID2=clusterID2,
              conditions=conditions,
              modelSignificance=modelSignificance,
              srate=srate,
              lowpassFilterOrder=lowpassFilterOrder,
              margin=margin,
              minPeakTime=minPeakTime,
              onlySignificantPeaks=onlySignificantPeaks,
              subjectsAndComponents1=subjectsAndComponents1,
              subjectsAndComponents2=subjectsAndComponents2,
              minAndMaxSFPDOfBestPredictionsFilenamePattern=
               minAndMaxSFPDOfBestPredictionsFilenamePattern,
              analyzedDataFilenamePattern=analyzedDataFilenamePattern,
              ...)
            answer <- rbind(answer, 
                             cbind(clusterID1=rep(clusterID1, times=nrow(res)), 
                                    clusterID2=rep(clusterID2, times=nrow(res)),
                                    res))
        }
    }
    return(answer)
}
