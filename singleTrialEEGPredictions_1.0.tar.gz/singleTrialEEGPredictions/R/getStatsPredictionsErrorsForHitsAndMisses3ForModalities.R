getStatsPredictionsErrorsForHitsAndMisses3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, modelSignificance,
                   dsAndPreviousSTDsInfo,
                   rtsInfo, dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD,
                   nResamples, conf, minN,
                   subjectsAndComponents,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    stats <- list()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        stats <- 
         c(stats, 
            list(list(modality=modality, 
                       stats=getStatsPredictionsErrorsForHitsAndMisses3ForClusters(
                              sortvar=sortvar,
                              modality=modality,
                              clustersIDs=clustersIDs,
                              conditions=conditions,
                              modelSignificance=modelSignificance,
                              dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                              rtsInfo=rtsInfo,
                              dfpdsInfo=dfpdsInfo,
                              maxRT=maxRT,
                              maxSTD_D_delay=maxSTD_D_delay,
                              maxDFPD=maxDFPD,
                              nResamples=nResamples,
                              conf=conf,
                              minN=minN,
                              subjectsAndComponents=subjectsAndComponents,
                              scFilenamePattern=scFilenamePattern,
                              minAndMaxSFPDOfBestPredictionsFilenamePattern=
                               minAndMaxSFPDOfBestPredictionsFilenamePattern,
                              analyzedDataFilenamePattern=
                               analyzedDataFilenamePattern))))
    }
    return(stats)
}
