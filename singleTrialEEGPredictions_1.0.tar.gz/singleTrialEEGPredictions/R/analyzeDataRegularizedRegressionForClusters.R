analyzeDataRegularizedRegressionForClusters <-
function(modality, sortvar, clustersIDs, conditions, 
                    subjectsAndComponents, 
                    scFilenamePattern,
                    preProcessedPhaseERPIFilenamePattern, 
                    analyzedConditionsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, interactions, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, computeCoefsCIs, maxIter, convergenceTol,
                    nResamplesCoefs, nResamplesPredictions, 
                    confCIs) {
    for(clusterID in clustersIDs) {
        if(is.null(subjectsAndComponents)) {
            scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
            if(is.null(scFilename)) {
                stop("arguments subjectsAndComponents or scFilenamePattern should be provided")
            }
            subjectsAndComponentsInCluster <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                                scFilename=scFilename)
        } else {
            subjectsAndComponentsInCluster <- subjectsAndComponents
        }
        show(sprintf("Processing cluster %2d", clusterID))
        analyzeDataRegularizedRegressionForConditions(
         modality=modality, 
         sortvar=sortvar, 
         clusterID=clusterID, 
         conditions=conditions, 
         subjectsAndComponents=subjectsAndComponentsInCluster,
         preProcessedPhaseERPIFilenamePattern=
          preProcessedPhaseERPIFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         interactions=interactions,
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, computeCoefsCIs=computeCoefsCIs,
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nResamplesCoefs=nResamplesCoefs,
         nResamplesPredictions=nResamplesPredictions, 
         confCIs=confCIs)
    }
}
