saveITCsPeaksForConditions <-
function(sortvar, 
                                        modality, 
                                        clusterID, 
                                        conditions,
                                        noctave, nvoice, nCycles,
                                        itcsFilenamePattern, 
                                        itcsPeaksFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing %s", condition))
        saveITCsPeaksForCondition(sortvar=sortvar,
                                   modality=modality,
                                   clusterID=clusterID,
                                   condition=condition,
                                   noctave=noctave, nvoice=nvoice, nCycles=nCycles,
                                   itcsFilenamePattern=
                                    itcsFilenamePattern, 
                                   itcsPeaksFilenamePattern=
                                    itcsPeaksFilenamePattern)
    }
}
