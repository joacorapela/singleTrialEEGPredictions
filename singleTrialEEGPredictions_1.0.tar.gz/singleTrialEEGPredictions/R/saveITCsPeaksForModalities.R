saveITCsPeaksForModalities <-
function(sortvar, 
                                        modalities, 
                                        clustersIDs, 
                                        conditions,
                                        noctave, nvoice, nCycles,
                                        itcsFilenamePattern, 
                                        itcsPeaksFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        saveITCsPeaksForClusters(sortvar=sortvar,
                                  modality=modality,
                                  clustersIDs=clustersIDs,
                                  conditions=conditions,
                                  noctave=noctave, nvoice=nvoice, nCycles=nCycles,
                                  itcsFilenamePattern=
                                   itcsFilenamePattern, 
                                  itcsPeaksFilenamePattern=
                                   itcsPeaksFilenamePattern)
    }
}
