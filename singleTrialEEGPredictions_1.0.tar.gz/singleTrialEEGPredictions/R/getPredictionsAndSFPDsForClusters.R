getPredictionsAndSFPDsForClusters <-
function(sortvar, modality, clustersIDs, conditions, 
                   modelSignificance,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        cDataSet <- getPredictionsAndSFPDsForConditions(
                     sortvar=sortvar,
                     modality=modality,
                     clusterID=clusterID,
                     conditions=conditions,
                     modelSignificance=modelSignificance, 
                     subjectsAndComponents=subjectsAndComponents,
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=
                      analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, cDataSet)
    }
    return(datasets)
}
