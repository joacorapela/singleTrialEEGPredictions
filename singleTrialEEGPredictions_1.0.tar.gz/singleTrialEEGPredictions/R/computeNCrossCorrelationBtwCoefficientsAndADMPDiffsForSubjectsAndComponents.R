computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition,
                   earlyFromPercentage, earlyToPercentage,
                   lateFromPercentage, lateToPercentage,
                   modelSignificance, minTimeSpanCoefsMS, srate,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   preProcessedPhaseERPIFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    subjectsNames <- c()
    components <- c()
    correlations <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
         correlation <- 
          computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForSubjectAndComponent(
           sortvar=sortvar,
           modality=modality,
           clusterID=clusterID,
           condition=condition,
           earlyFromPercentage=earlyFromPercentage,
           earlyToPercentage=earlyToPercentage,
           lateFromPercentage=lateFromPercentage,
           lateToPercentage=lateToPercentage,
           subjectName=subjectName,
           component=component,
           modelSignificance=modelSignificance,
           minTimeSpanCoefsMS=minTimeSpanCoefsMS,
           srate=srate,
           minAndMaxSFPDOfBestPredictionsFilenamePattern=
            minAndMaxSFPDOfBestPredictionsFilenamePattern,
           preProcessedPhaseERPIFilenamePattern=
            preProcessedPhaseERPIFilenamePattern,
           analyzedDataFilenamePattern=analyzedDataFilenamePattern,
           ...)
        if(!is.null(correlation)) {
            subjectsNames <- c(subjectsNames, subjectName)
            components <- c(components, component)
            correlations <- c(correlations, correlation)
        }
    }
    if(length(subjectsNames)>0) {
        return(data.frame(subjectName=subjectsNames, 
                           component=components,
                           correlation=correlations))
    } else {
        return(data.frame())
    }
}
