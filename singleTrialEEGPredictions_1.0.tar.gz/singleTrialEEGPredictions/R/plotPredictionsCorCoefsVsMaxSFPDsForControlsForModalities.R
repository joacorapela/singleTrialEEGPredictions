plotPredictionsCorCoefsVsMaxSFPDsForControlsForModalities <-
function(sortvar, modalities, clustersIDs, conditions, minSFPD, maxSFPDs,
                   nResamples, modelSignificance, ciConf,
                   subjectsAndComponents, 
                   coefsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotPredictionsCorCoefsVsMaxSFPDsForControlsForClusters(
         sortvar=sortvar, 
         modality=modality, 
         clustersIDs=clustersIDs, 
         conditions=conditions, 
         minSFPD=minSFPD,
         maxSFPDs=maxSFPDs,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         ciConf=ciConf,
         subjectsAndComponents=subjectsAndComponents,
         coefsFilenamePattern=coefsFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         ...)
    }
}
