computeITCsForClusters <-
function(modality,
                                    sortvar,
                                    clustersIDs, 
                                    conditions,
                                    noctave, nvoice, nCycles, 
                                    minTime, 
                                    maxTime, 
                                    significance,
                                    conf,
                                    peakFromTime, peakToTime, 
                                    peakFromFreq, peakToFreq,
                                    nResamples,
                                    erpimageFilenamePattern, 
                                    itcsFilenamePattern,
                                    scFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %2d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponentsInCluster <- 
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        computeITCsForConditions(modality=modality, 
                                  sortvar=sortvar, 
                                  clusterID=clusterID, 
                                  conditions=conditions,
                                  subjectsAndComponentsInCluster=
                                   subjectsAndComponentsInCluster,
                                  noctave=noctave, 
                                  nvoice=nvoice, 
                                  nCycles=nCycles, 
                                  minTime=minTime, 
                                  maxTime=maxTime,
                                  significance=significance,
                                  conf=conf,
                                  peakFromTime=peakFromTime, 
                                  peakToTime=peakToTime,
                                  peakFromFreq=peakFromFreq, 
                                  peakToFreq=peakToFreq,
                                  nResamples=nResamples, 
                                  erpimageFilenamePattern=
                                   erpimageFilenamePattern,
                                  itcsFilenamePattern=itcsFilenamePattern)
    }
}
