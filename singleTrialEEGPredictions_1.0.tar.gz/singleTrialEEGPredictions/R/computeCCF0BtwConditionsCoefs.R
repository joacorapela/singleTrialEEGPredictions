computeCCF0BtwConditionsCoefs <-
function(times1, condition1Coefs, 
                                                 times2, condition2Coefs, 
                                                 minOverlapMS, srate,
                                                 nResamples) {
    matchRes <- match(x=times1, table=times2)
    c1CommonTimeIndices <- which(!is.na(matchRes))
    c2CommonTimeIndices <- matchRes[c1CommonTimeIndices]
    minNumberOfCommonIndices <- minOverlapMS*srate/1000
    if(length(c1CommonTimeIndices)>=minNumberOfCommonIndices) {
        permRes <- permuteCCF0(x=condition1Coefs[c1CommonTimeIndices],
                                      y=condition2Coefs[c2CommonTimeIndices],
                                      nResamples=nResamples)
        ccf0 <- permRes$t0
        pValue <- sum(abs(permRes$t)>abs(permRes$t0))/length(permRes$t)
    } else {
        ccf0 <- NaN
        pValue <- NaN
    }
    return(list(ccf0=ccf0, pValue=pValue))
}
