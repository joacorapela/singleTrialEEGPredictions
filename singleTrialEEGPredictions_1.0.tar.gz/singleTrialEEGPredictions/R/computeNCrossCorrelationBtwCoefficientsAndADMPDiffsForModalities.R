computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                   earlyFromPercentage, earlyToPercentage,
                   lateFromPercentage, lateToPercentage,
                   modelSignificance, minTimeSpanCoefsMS, srate,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   preProcessedPhaseERPIFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        res <- 
         computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForClusters(
          sortvar=sortvar,
          modality=modality,
          clustersIDs=clustersIDs,
          conditions=conditions,
          earlyFromPercentage=earlyFromPercentage,
          earlyToPercentage=earlyToPercentage,
          lateFromPercentage=lateFromPercentage,
          lateToPercentage=lateToPercentage,
          modelSignificance=modelSignificance,
          minTimeSpanCoefsMS=minTimeSpanCoefsMS,
          srate=srate,
          scFilenamePattern=scFilenamePattern,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          preProcessedPhaseERPIFilenamePattern=
           preProcessedPhaseERPIFilenamePattern,
          analyzedDataFilenamePattern=
           analyzedDataFilenamePattern, 
          ...)
        answer <- rbind(answer, 
                         cbind(modality=rep(modality, times=nrow(res)), res))
    }
    return(answer)
}
