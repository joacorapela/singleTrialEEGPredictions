computeITCForCondition <-
function(modality,
                                    sortvar,
                                    clusterID,
                                    condition, 
                                    subjectsAndComponentsInCluster,
                                    noctave, nvoice, nCycles, 
                                    minTime, 
                                    maxTime, 
                                    significance,
                                    conf,
                                    peakFromTime, peakToTime, 
                                    peakFromFreq, peakToFreq,
                                    nResamples,
                                    erpimageFilenamePattern,
                                    itcsFilenamePattern) {
    condERPImageFilenamePattern <- sprintf(erpimageFilenamePattern, clusterID,
                                                                    condition,
                                                                    sortvar,
                                                                    modality)
    itcsFilename <- sprintf(itcsFilenamePattern, clusterID, condition, sortvar, modality, noctave, nvoice, nCycles)
    resLoadData <- loadERPImageData(filenamesPattern=
                                     condERPImageFilenamePattern)
    trials <- resLoadData$data
    times <- resLoadData$times
    srate <- resLoadData$metaData$srate
    subjectsNames <- resLoadData$subjectsNames
    components <- resLoadData$components

    itcsRes <- list()
    for(subjectName in unique(subjectsNames)) {
        subjectComponents <- 
         getSubjectComponents(subjectName=subjectName, 
                               subjectsAndComponents=
                                subjectsAndComponentsInCluster)
        for(component in subjectComponents) {
            show(sprintf("Processing subject %s, component %02d",
                         subjectName, component))
            scCases <- getSubjectAndComponentCases(
                        subjectName=subjectName, 
                        component=component,
                        subjectsNames=subjectsNames,
                        components=components)
            if(length(scCases)==0) {
                stop(sprintf("subject %s and component %02d not found", 
                             subjectName, component))
            }
            scTrials <- trials[, scCases]
            selectedTimesIndices = which(minTime<=times & times<=maxTime)
            selectedTimes <- times[selectedTimesIndices]
            scTrialsWithSelectedTimes <- scTrials[selectedTimesIndices,]
            itcRes <- computeITCWithSignificanceMaskAndPeakCI(
                       times=selectedTimes,
                       trials=scTrialsWithSelectedTimes,
                       noctave=noctave, 
                       nvoice=nvoice, 
                       w0=pi/3*nCycles, 
                       srate=srate, 
                       peakFromTime=peakFromTime,
                       peakToTime=peakToTime,
                       peakFromFreq=peakFromFreq,
                       peakToFreq=peakToFreq,
                       nResamples=nResamples,
                       significance=significance,
                       conf=conf)
               itcsRes <- c(itcsRes, list(c(subjectName=subjectName, 
                                             component=component,
                                             itcRes)))
        }
    }
    save(itcsRes, file=itcsFilename)
}
