plotPredictionsCorCoefsVsMaxSFPDsForControlsForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition, minSFPD, maxSFPDs,
                   nResamples, modelSignificance, ciConf,
                   subjectName, 
                   component,
                   coefsFilenamePattern,
                   plotsFilenamePattern,
                   xlab,
                   ylab="Correlation Coefficient",
                   main="", 
                   ...) {
    i <- 1
    predSFPDurCorsCIs <- c()
    while(i<=length(maxSFPDs)) {
        maxSFPD <- maxSFPDs[i]
        coefsFilename <- sprintf(coefsFilenamePattern,
                                              clusterID,
                                              clusterID,
                                              condition,
                                              sortvar,
                                              modality,
                                              subjectName,
                                              component,
                                              minSFPD,
                                              maxSFPD)
        if(!file.exists(coefsFilename)) {
            break
        }
        show(sprintf("Processing maxSFPD %d", maxSFPDs[i]))
        coefs <- get(load(coefsFilename))
        bootRes <- bootstrapMedian(coefs, nResamples=nResamples)
        controlCI <- getBootstrapCIs(bootRes, conf=ciConf)
        predSFPDurCorsCIs <- rbind(predSFPDurCorsCIs, controlCI)
        i <- i+1
    }
    usedMaxSFPDs <- maxSFPDs[1:(i-1)]
    if(nrow(predSFPDurCorsCIs)>1) {
        plotCIsForCategories(categoriesNames=sprintf("%d", usedMaxSFPDs), 
                              cis=predSFPDurCorsCIs, 
                              xlab=xlab, ylab=ylab, main=main, ...)
    } else {
        print(getEmptyPlot())
    }
    plotFilename <- sprintf(plotsFilenamePattern, 
                             clusterID, 
                             clusterID, 
                             condition,
                             sortvar, 
                             modality, 
                             subjectName,
                             component)
    ggsave(filename=plotFilename)
}
