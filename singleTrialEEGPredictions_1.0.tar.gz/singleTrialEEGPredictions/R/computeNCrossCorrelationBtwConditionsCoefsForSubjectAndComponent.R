computeNCrossCorrelationBtwConditionsCoefsForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition1, condition2,
                   minOverlapMS, srate,
                   subjectName, component, modelSignificance,
                   nResamples, minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    c1MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
              clusterID, condition1, sortvar, modality, subjectName, component)
    res <- readLines(c1MinAndMaxSFPDOfBestPredictionsFilename)
    c1MinSFPD <- as.integer(res[1])
    c1MaxSFPD <- as.integer(res[2])
    c2MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
              clusterID, condition2, sortvar, modality, subjectName, component)
    res <- readLines(c2MinAndMaxSFPDOfBestPredictionsFilename)
    c2MinSFPD <- as.integer(res[1])
    c2MaxSFPD <- as.integer(res[2])
    if(!is.na(c1MinSFPD) && !is.na(c1MaxSFPD) && 
       !is.na(c2MinSFPD) && !is.na(c2MaxSFPD)) {
        c1AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID,
                                       clusterID,
                                       condition1,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component,
                                       c1MinSFPD,
                                       c1MaxSFPD)
        c2AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID,
                                       clusterID,
                                       condition2,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component,
                                       c2MinSFPD,
                                       c2MaxSFPD)
        c1AnalyzedData <- get(load(c1AnalyzedDataFilename))
        c2AnalyzedData <- get(load(c2AnalyzedDataFilename))

        if(!is.null(c1AnalyzedData$lrtRes) &&
           c1AnalyzedData$lrtRes$pValue<modelSignificance && 
           !is.null(c2AnalyzedData$lrtRes) && 
           c2AnalyzedData$lrtRes$pValue<modelSignificance) {
            res <- computeNCrossCorrelationBtwConditionsCoefs(
                    times1=c1AnalyzedData$times,
                    condition1Coefs=c1AnalyzedData$coefsCIs[-1,1], 
                    times2=c2AnalyzedData$times,
                    minOverlapMS=minOverlapMS,
                    srate=srate,
                    condition2Coefs=c2AnalyzedData$coefsCIs[-1,1],
                    nResamples=nResamples)
            correlation <- res$correlation
            pValue <- res$pValue
            return(c(correlation, pValue))
        }
    }
    return(NULL)
}
