plotRegLMCoefficientsForModalities <-
function(sortvar, 
           modalities, 
           clustersIDs,
           conditions,
           unstandardize,
           subjectsAndComponents,
           scFilenamePattern,
           minSFPDs, maxSFPDs,
           analyzedConditionsFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ...) {
    if(!is.null(subjectsAndComponents) && !is.null(scFilenamePattern)) {
        warning("Both subjectsAndComponents and scFilenamePattern are given.  Using only subjectsAndComponents")
    }
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotRegLMCoefficientsForClusters(sortvar=sortvar, 
                                            modality=modality,
                                            clustersIDs=clustersIDs, 
                                            conditions=conditions,
                                            unstandardize=unstandardize,
                                            subjectsAndComponents=
                                             subjectsAndComponents,
                                            scFilenamePattern=scFilenamePattern,
                                            minSFPDs=minSFPDs, 
                                            maxSFPDs=maxSFPDs,
                                            analyzedConditionsFilenamePattern=
                                             analyzedConditionsFilenamePattern,
                                            plotsFilenamePattern=
                                             plotsFilenamePattern,
                                            xlim=xlim, 
                                            ...)
    }
}
