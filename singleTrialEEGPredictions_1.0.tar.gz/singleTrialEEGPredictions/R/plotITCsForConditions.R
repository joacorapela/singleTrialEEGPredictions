plotITCsForConditions <-
function(sortvar,
           modality, 
           clusterID, 
           conditions,
           noctave, nvoice, nCycles, 
           itcFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ylim,
           zlim,
           cuts,
           nFreqTicks) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        itcFilename <- sprintf(itcFilenamePattern, clusterID, condition, 
                                                           sortvar, modality, 
                                                           noctave, nvoice, nCycles)
        itcRes <- get(load(itcFilename))
        plotITCForCondition(sortvar=sortvar,
                                    modality=modality,
                                    clusterID=clusterID,
                                    condition=condition,
                                    noctave=noctave, 
                                    nvoice=nvoice, 
                                    nCycles=nCycles,
                                    itcRes=itcRes,
                                    plotsFilenamePattern=
                                     plotsFilenamePattern,
                                    xlim=xlim,
                                    ylim=ylim,
                                    zlim=zlim,
                                    cuts=cuts,
                                    nFreqTicks=nFreqTicks)
    }
}
