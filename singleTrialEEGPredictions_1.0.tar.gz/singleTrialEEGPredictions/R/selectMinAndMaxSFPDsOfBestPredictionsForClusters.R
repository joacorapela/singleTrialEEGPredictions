selectMinAndMaxSFPDsOfBestPredictionsForClusters <-
function(sortvar, modality, clustersIDs, conditions, scFilenamePattern,
                   minSFPDs, maxSFPDs, analyzedDataFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %2d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        selectMinAndMaxSFPDsOfBestPredictionsForConditions(sortvar=sortvar, 
                                        modality=modality, 
                                        clusterID=clusterID, 
                                        conditions=conditions, 
                                        subjectsAndComponents=
                                         subjectsAndComponents,
                                        minSFPDs=minSFPDs, 
                                        maxSFPDs=maxSFPDs, 
                                        analyzedDataFilenamePattern=
                                         analyzedDataFilenamePattern,
                                        minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                         minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
