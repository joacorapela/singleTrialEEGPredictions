getPredCorCoefs2ForClusters <-
function(sortvar, modality, condition, clustersIDs, 
                   modelSignificance,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    predCorCoefs <- c()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        subjectsPredCorCoefs <- getPredCorCoefs2ForSubjects(
                   sortvar=sortvar,
                   modality=modality,
                   condition=condition,
                   clusterID=clusterID,
                   modelSignificance=modelSignificance,
                   subjectsAndComponents=subjectsAndComponents,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern=
                     minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        predCorCoefs <- c(predCorCoefs, subjectsPredCorCoefs)
    }
    return(predCorCoefs)
}
