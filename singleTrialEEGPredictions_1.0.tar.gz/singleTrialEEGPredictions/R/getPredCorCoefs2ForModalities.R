getPredCorCoefs2ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, minSFPD, maxSFPD,
                   significance,
                   scFilenamePattern, analyzedConditionsFilenamePattern) {
    predCorCoefs <- data.frame()
    for(modality in modalities) {
        modalityPredCorCoefs <- getPredCorCoefs2ForClusters(
                        sortvar=sortvar,
                        modality=modality,
                        clustersIDs=clustersIDs,
                        conditions=conditions,
                        minSFPD=minSFPD,
                        maxSFPD=maxSFPD,
                        significance=significance,
                        scFilenamePattern=scFilenamePattern,
                        analyzedConditionsFilenamePattern=
                         analyzedConditionsFilenamePattern)
        if(length(modalityPredCorCoefs)>0) {
            modalityPredCorCoefs["modality"] <- modality
            predCorCoefs <- rbind(predCorCoefs, modalityPredCorCoefs)
        }
    }
    predCorCoefs$modality  <- as.factor(predCorCoefs$modality)
    predCorCoefs$clusterID <- as.factor(predCorCoefs$clusterID)
    predCorCoefs$condition <- as.factor(predCorCoefs$condition)
    predCorCoefs$subject   <- as.factor(predCorCoefs$subject)
    return(predCorCoefs)
}
