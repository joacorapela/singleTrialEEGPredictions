analyzeDataRegularizedRegressionForModalities <-
function(modalities, sortvar, clustersIDs, conditions, 
                      subjectsAndComponents, 
                      scFilenamePattern,
                      preProcessedPhaseERPIFilenamePattern, 
                      analyzedConditionsFilenamePattern, 
                      minSFPDs, maxSFPDs, lambda, order, scaleData, 
                      nGroups, 
                      a0, b0, c0, d0, computeCoefsCIs, maxIter, convergenceTol,
                      nResamplesCoefs, nResamplesPredictions, 
                      confCIs) {
    if(!is.null(subjectsAndComponents) && !is.null(scFilenamePattern)) {
        warning("Both subjectsAndComponents and scFilenamePattern are given.  Using only subjectsAndComponents")
    }
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        analyzeDataRegularizedRegressionForClusters(
         modality=modality, 
         sortvar=sortvar, 
         clustersIDs=clustersIDs, 
         conditions=conditions, 
         subjectsAndComponents=subjectsAndComponents,
         scFilenamePattern=scFilenamePattern,
         preProcessedPhaseERPIFilenamePattern=preProcessedPhaseERPIFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         interactions=interactions,
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, computeCoefsCIs=computeCoefsCIs,
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nResamplesCoefs=nResamplesCoefs,
         nResamplesPredictions=nResamplesPredictions, 
         confCIs=confCIs)
    }
}
