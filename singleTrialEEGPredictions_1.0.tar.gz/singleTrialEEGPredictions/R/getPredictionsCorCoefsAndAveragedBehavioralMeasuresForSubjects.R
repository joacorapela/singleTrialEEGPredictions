getPredictionsCorCoefsAndAveragedBehavioralMeasuresForSubjects <-
function(sortvar, modality, clusterID, condition,
                   errorRatesAndMeanRTsStats,
                   getSubjectBehavioralMeasureCIFunc, 
                   subjectsAndComponents, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    predSFPDurCors <- c()
    behavioralMeasures <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
                  clusterID, condition, sortvar, modality, subjectName, 
                  component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        if(is.nan(minSFPD) || is.na(maxSFPD)) {
            predSFPDurCors <- c(predSFPDurCors, 0)
        } else {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                             clusterID,
                                             clusterID,
                                             condition,
                                             sortvar,
                                             modality,
                                             subjectName,
                                             component,
                                             minSFPD,
                                             maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))

            if(!is.null(analyzedData$predSFPDurCorCI)) {
                predSFPDurCorCI <- analyzedData$predSFPDurCorCI
                predSFPDurCors <- c(predSFPDurCors, predSFPDurCorCI[1])
            } else {
                predSFPDurCors <- c(predSFPDurCors, 0)
            }
        }
        behavioralMeasure <- getSubjectBehavioralMeasureCIFunc(
                              subjectName=subjectName, 
                              condition=condition, 
                              stats=errorRatesAndMeanRTsStats)[1]
        behavioralMeasures <- c(behavioralMeasures, behavioralMeasure)
    }
    if(length(behavioralMeasures)>2) {
        metaData <- list(modality=modality, clusterID=clusterID,
                                            condition=condition)
        return(list(x=behavioralMeasures, y=predSFPDurCors, metaData=metaData))
    }
    return(list())
}
