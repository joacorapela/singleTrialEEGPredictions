tr <-
function(m) {
    return(sum(diag(m)))
}
