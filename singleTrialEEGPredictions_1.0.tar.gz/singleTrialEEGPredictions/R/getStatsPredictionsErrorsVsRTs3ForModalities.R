getStatsPredictionsErrorsVsRTs3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, modelSignificance,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD, 
                   nResamples, conf,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    stats <- list()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        stats <- 
         c(stats, 
            list(list(modality=modality, 
                       stats=getStatsPredictionsErrorsVsRTs3ForClusters(
                              sortvar=sortvar,
                              modality=modality,
                              clustersIDs=clustersIDs,
                              conditions=conditions,
                              modelSignificance=modelSignificance,
                              dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                              rtsInfo=rtsInfo,
                              dfpdsInfo=dfpdsInfo,
                              maxRT=maxRT,
                              maxSTD_D_delay=maxSTD_D_delay,
                              maxDFPD=maxDFPD,
                              nResamples=nResamples,
                              conf=conf,
                              scFilenamePattern=scFilenamePattern,
                              minAndMaxSFPDOfBestPredictionsFilenamePattern=
                               minAndMaxSFPDOfBestPredictionsFilenamePattern,
                              analyzedDataFilenamePattern=
                               analyzedDataFilenamePattern, ...))))
    }
    stats$modality <- factor(stats$modality)
    stats$clusterID <- factor(stats$clusterID)
    stats$condition <- factor(stats$condition)
    return(stats)
}
