l2Norm2 <-
function(x) {
    return(sum(x^2))
}
