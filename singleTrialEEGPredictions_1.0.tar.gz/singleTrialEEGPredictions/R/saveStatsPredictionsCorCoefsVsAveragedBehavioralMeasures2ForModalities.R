saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, nResamples, conf,
                   modelSignificance, errorRatesAndMeanRTsStats, 
                   getSubjectBehavioralMeasureCIFunc, 
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   statsFilenamePattern, ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForClusters(
         sortvar=sortvar,
         modality=modality,
         clustersIDs=clustersIDs,
         conditions=conditions,
         nResamples=nResamples,
         conf=conf,
         modelSignificance=modelSignificance,
         errorRatesAndMeanRTsStats=errorRatesAndMeanRTsStats,
         getSubjectBehavioralMeasureCIFunc=getSubjectBehavioralMeasureCIFunc,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         statsFilenamePattern=statsFilenamePattern, 
         ...)
    }
}
