getStatsAllCoefsEnergy2ForConditions <-
function(sortvar, modality, conditions, clustersIDs, 
                   modelSignificance, nResamples, ciConf,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    answer <- c()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        allCoefsEnergy <- getAllCoefsEnergy2ForClusters(
                   sortvar=sortvar,
                   modality=modality,
                   condition=condition,
                   clustersIDs=clustersIDs,
                   modelSignificance=modelSignificance,
                   scFilenamePattern=scFilenamePattern,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern=
                     minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        bootRes <- bootstrapMean(allCoefsEnergy, nResamples=nResamples)
        bootCI <- getBootstrapCIs(bootRes=bootRes, conf=ciConf)
        answer <- c(answer, list(list(condition=condition,
                                       stats=list(range=range(allCoefsEnergy),
                                                   mean=bootCI[1],
                                                   meanCIL=bootCI[2],
                                                   meanCIU=bootCI[3]))))
    }
    return(answer)
}
