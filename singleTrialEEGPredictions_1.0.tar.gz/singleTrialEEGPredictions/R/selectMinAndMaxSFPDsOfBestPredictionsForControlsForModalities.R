selectMinAndMaxSFPDsOfBestPredictionsForControlsForModalities <-
function(sortvar, modalities, clustersIDs, conditions, scFilenamePattern,
                   minSFPDs, maxSFPDs, corCoefsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        selectMinAndMaxSFPDsOfBestPredictionsForControlsForClusters(sortvar=sortvar, 
                                    modality=modality, 
                                    clustersIDs=clustersIDs, 
                                    conditions=conditions, 
                                    scFilenamePattern=
                                     scFilenamePattern,
                                    minSFPDs=minSFPDs, 
                                    maxSFPDs=maxSFPDs, 
                                    corCoefsFilenamePattern=
                                     corCoefsFilenamePattern,
                                    minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                     minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
