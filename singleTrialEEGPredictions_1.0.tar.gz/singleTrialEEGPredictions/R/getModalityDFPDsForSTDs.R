getModalityDFPDsForSTDs <-
function(modality, condition,
                                              dfpdsForSTDsInfoForModalities) {
    for(i in 1:length(dfpdsForSTDsInfoForModalities)) {
        if(dfpdsForSTDsInfoForModalities[[i]]$modality==modality) {
            dfpdsForSTDsInfoForConditions <- 
             dfpdsForSTDsInfoForModalities[[i]]$dfpdsForSTDsInfo
            return(getConditionDFPDsForSTDs(condition=condition,
                                             dfpdsForSTDsInfoForConditions=
                                              dfpdsForSTDsInfoForConditions))
        }
    }
    stop(sprintf("Modality %s not found", modality))
}
