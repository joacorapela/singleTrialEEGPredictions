getModalityAndConditionIndicesForSubject <-
function(subjectName, modality,
                                                                  condition,
                                                                  df) {
    indices <- which(df$subjectName==subjectName & df$modality==modality & 
                                                   df$condition==condition)
    return(indices)
}
