getPredCorCoefs2ForConditions <-
function(sortvar, modality, clusterID, conditions, minSFPD, maxSFPD,
                   significance,
                   subjectsAndComponents=subjectsAndComponents,
                   analyzedConditionsFilenamePattern) {
    predCorCoefs <- data.frame()
    for(condition in conditions) {
        conditionPredCorCoefs <- getPredCorCoefs2ForSubjects(
                                  sortvar=sortvar,
                                  modality=modality,
                                  clusterID=clusterID,
                                  condition=condition,
                                  minSFPD=minSFPD,
                                  maxSFPD=maxSFPD,
                                  significance=significance,
                                  subjectsAndComponents=subjectsAndComponents,
                                  analyzedConditionsFilenamePattern=
                                   analyzedConditionsFilenamePattern)
        if(length(conditionPredCorCoefs)>0) {
            conditionPredCorCoefs["condition"] <- condition
            predCorCoefs <- rbind(predCorCoefs, conditionPredCorCoefs)
        }
    }
    return(predCorCoefs)
}
