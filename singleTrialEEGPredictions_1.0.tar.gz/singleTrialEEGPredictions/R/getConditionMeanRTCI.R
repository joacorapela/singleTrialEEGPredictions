getConditionMeanRTCI <-
function(condition, stats) {
    for(i in 1:length(stats)) {
        if(condition==stats[[i]]$condition) {
            return(stats[[i]]$stats$meanRTCI)
        }
    }
    stop(sprintf("Could not find condition %s", condition))
}
