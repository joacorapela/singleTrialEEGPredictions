computePeakAbsTimeDifBtwClustersCoefsForConditions <-
function(sortvar, modality, clusterID1, clusterID2, conditions,
                   modelSignificance, srate, lowpassFilterOrder, margin,
                   minPeakTime, onlySignificantPeaks,
                   subjectsAndComponents1, subjectsAndComponents2, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        res <- 
         computePeakAbsTimeDifBtwClustersCoefsForSubjectsAndComponents(
          sortvar=sortvar,
          modality=modality,
          clusterID1=clusterID1,
          clusterID2=clusterID2,
          condition=condition,
          modelSignificance=modelSignificance,
          srate=srate,
          lowpassFilterOrder=lowpassFilterOrder,
          margin=margin,
          minPeakTime=minPeakTime,
          onlySignificantPeaks=onlySignificantPeaks,
          subjectsAndComponents1=subjectsAndComponents1,
          subjectsAndComponents2=subjectsAndComponents2,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          analyzedDataFilenamePattern=analyzedDataFilenamePattern,
          ...)
        answer <- rbind(answer, 
                         cbind(condition=rep(condition, times=nrow(res)), res))
    }
    return(answer)
}
