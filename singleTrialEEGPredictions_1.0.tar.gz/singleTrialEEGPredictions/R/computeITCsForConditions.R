computeITCsForConditions <-
function(modality, 
                                      sortvar, 
                                      clusterID,
                                      conditions, 
                                      subjectsAndComponentsInCluster,
                                      noctave, nvoice, nCycles, 
                                      minTime, 
                                      maxTime, 
                                      significance,
                                      conf,
                                      peakFromTime, peakToTime, 
                                      peakFromFreq, peakToFreq,
                                      nResamples,
                                      erpimageFilenamePattern, 
                                      itcsFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        computeITCForCondition(modality=modality, 
                                sortvar=sortvar,
                                clusterID=clusterID,
                                condition=condition,
                                subjectsAndComponentsInCluster=
                                 subjectsAndComponentsInCluster,
                                noctave=noctave, 
                                nvoice=nvoice, 
                                nCycles=nCycles, 
                                minTime=minTime, maxTime=maxTime,
                                significance=significance,
                                conf=conf,
                                peakFromTime=peakFromTime, 
                                peakToTime=peakToTime,
                                peakFromFreq=peakFromFreq, 
                                peakToFreq=peakToFreq,
                                nResamples=nResamples, 
                                erpimageFilenamePattern=erpimageFilenamePattern,
                                itcsFilenamePattern=itcsFilenamePattern)
    }
}
