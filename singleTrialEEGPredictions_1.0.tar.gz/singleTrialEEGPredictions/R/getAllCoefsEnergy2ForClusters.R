getAllCoefsEnergy2ForClusters <-
function(sortvar, modality, condition, clustersIDs, 
                   modelSignificance,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    allCoefsEnergy <- c()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        subjectsAllCoefsEnergy <- getAllCoefsEnergy2ForSubjects(
                   sortvar=sortvar,
                   modality=modality,
                   condition=condition,
                   clusterID=clusterID,
                   modelSignificance=modelSignificance,
                   subjectsAndComponents=subjectsAndComponents,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern=
                     minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        allCoefsEnergy <- c(allCoefsEnergy, subjectsAllCoefsEnergy)
    }
    return(allCoefsEnergy)
}
