plotPredictionsCorCoefsVsMaxSFPDs2ForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition, maxSFPDs,
                   nResamples, modelSignificance, rConf,
                   subjectsAndComponents, 
                   analyzedConditionsFilenamePattern,
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    predSFPDurCorsCIs <- c()
    behavioralMeasuresCIs <- c()
    scNames <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
        plotPredictionsCorCoefsVsMaxSFPDs2ForSubjectAndComponent(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         maxSFPDs=maxSFPDs,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         rConf=rConf,
         subjectName=subjectName,
         component=component,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern, 
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab,
         ylab=ylab,
         main=main,
         ...)
    }
}
