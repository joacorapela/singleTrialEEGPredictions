printStatsPredictionsErrorsAndBehavioralMeasuresForSubjects <-
function(sortvar, modality, clusterID, condition,
                    sFPStatsForSubjects, dFPStats, 
                    modelSignificance,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                    analyzedDataFilenamePattern,
                    filterSFPStatsFunc, filterDFPStatsFunc, 
                    printUnselectedSFPStats,
                    printUnselectedDFPStats,
                    printSFPAndDFPStatsFunc,
                    printSFPStatsFunc,
                    con) {
    for(i in 1:length(sFPStatsForSubjects)) {
        sFPStatsForSubject <- sFPStatsForSubjects[[i]]
        selectedDFPStats <- 
         selectDFPStats(subjectsDFPStats=dFPStats, 
                         subjectName=sFPStatsForSubject$subjectName,
                         condition=condition)
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, 
                  clusterID, clusterID, condition, sortvar, modality, 
                  sFPStatsForSubject$subjectName, sFPStatsForSubject$component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        if(!is.na(minSFPD) && !is.na(maxSFPD)) {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                             clusterID,
                                             clusterID,
                                             condition,
                                             sortvar,
                                             modality,
                                             sFPStatsForSubject$subjectName,
                                             sFPStatsForSubject$component,
                                             minSFPD,
                                             maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))
            if(length(analyzedData$lrtRes)>0 &&
                       analyzedData$lrtRes$pValue<modelSignificance &&
                       length(sFPStatsForSubject$stats)>0) {
                printStatsPredictionsErrorsAndBehavioralMeasuresForSubject(
                 modality=modality, clusterID=clusterID, condition=condition,
                 subjectName=sFPStatsForSubject$subjectName,
                 component=sFPStatsForSubject$component,
                 sFPStatsForSubject=sFPStatsForSubject$stats, 
                 selectedDFPStats=selectedDFPStats,
                 modelPredictionCI=analyzedData$predSFPDurCorCI,
                 filterSFPStatsFunc=filterSFPStatsFunc, 
                 filterDFPStatsFunc=filterDFPStatsFunc, 
                 printUnselectedSFPStats=printUnselectedSFPStats,
                 printUnselectedDFPStats=printUnselectedDFPStats,
                 printSFPAndDFPStatsFunc=printSFPAndDFPStatsFunc,
                 printSFPStatsFunc=printSFPStatsFunc,
                 con=con)
            }
        }
    }
}
