printStatsPredictionsErrorsAndBehavioralMeasuresForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                    sFPStatsForClusters, 
                    dFPStats, 
                    modelSignificance,
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                    analyzedDataFilenamePattern,
                    filterSFPStatsFunc, 
                    filterDFPStatsFunc,
                    printUnselectedSFPStats,
                    printUnselectedDFPStats,
                    printSFPAndDFPStatsFunc,
                    printSFPStatsFunc,
                    con) {
    for(clusterID in clustersIDs) {
        sFPStatsForConditions <-
         getItemInAVShiftList(listOfItems=sFPStatsForClusters,
                               listFieldName="stats",
                               keyFieldNames=c("clusterID"),
                               keyFieldValues=c(clusterID))
        printStatsPredictionsErrorsAndBehavioralMeasuresForConditions( 
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         conditions=conditions, 
         sFPStatsForConditions=sFPStatsForConditions,
         dFPStats=dFPStats,
         modelSignificance=modelSignificance,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         filterSFPStatsFunc=filterSFPStatsFunc,
         filterDFPStatsFunc=filterDFPStatsFunc,
         printUnselectedSFPStats=printUnselectedSFPStats,
         printUnselectedDFPStats=printUnselectedDFPStats,
         printSFPAndDFPStatsFunc=printSFPAndDFPStatsFunc,
         printSFPStatsFunc=printSFPStatsFunc,
         con=con)
    }
}
