saveAmpPhaseERPImagesForClusters <-
function(sortvar, 
                                              modality, 
                                              clustersIDs, 
                                              conditions, 
                                              noctave, nvoice, nCycles, 
                                              minTime, 
                                              maxTime, 
                                              shuffleSFPDs,
                                              sfpdsInfo,
                                              itcsPeaksFilenamePattern, 
                                              erpimageFilenamePattern,
                                              apERPImagesFilenamePattern,
                                              scFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        saveAmpPhaseERPImagesForConditions(sortvar=sortvar, 
                                            modality=modality,
                                            clusterID=clusterID,
                                            conditions=conditions,
                                            subjectsAndComponents=
                                             subjectsAndComponents,
                                            noctave=noctave,
                                            nvoice=nvoice,
                                            nCycles=nCycles,
                                            minTime=minTime, 
                                            maxTime=maxTime, 
                                            shuffleSFPDs=shuffleSFPDs,
                                            sfpdsInfo=sfpdsInfo,
                                            itcsPeaksFilenamePattern=
                                             itcsPeaksFilenamePattern,
                                            erpimageFilenamePattern=
                                             erpimageFilenamePattern,
                                            apERPImagesFilenamePattern=
                                             apERPImagesFilenamePattern,
                                            scFilenamePattern=scFilenamePattern)
    }
}
