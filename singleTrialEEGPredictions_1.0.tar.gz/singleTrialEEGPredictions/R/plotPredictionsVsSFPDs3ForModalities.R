plotPredictionsVsSFPDs3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, 
                   adjustedPValuesDF,
                   corCoefAnnotationFunction,
                   subjectsAndComponents, scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotPredictionsVsSFPDs3ForClusters(sortvar=sortvar, 
                                            modality=modality,
                                            clustersIDs=clustersIDs, 
                                            conditions=conditions,
                                            adjustedPValuesDF=adjustedPValuesDF,
                                            corCoefAnnotationFunction=
                                             corCoefAnnotationFunction,
                                            subjectsAndComponents=
                                             subjectsAndComponents,
                                            scFilenamePattern=scFilenamePattern,
                                            minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                             minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                            analyzedDataFilenamePattern=
                                             analyzedDataFilenamePattern,
                                            plotsFilenamePattern=
                                             plotsFilenamePattern,
                                            width=width, 
                                            height=height,
                                            ...)
    }
}
