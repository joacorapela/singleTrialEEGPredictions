getPredictionsCorCoefsAndAveragedBehavioralMeasuresForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                   errorRatesAndMeanRTsStats, 
                   getSubjectBehavioralMeasureCIFunc, 
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    predCorCoefsAndABMs <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID,
                                            scFilename=scFilename)
        cPredCorCoefsAndABMs <-getPredictionsCorCoefsAndAveragedBehavioralMeasuresForConditions(
                                sortvar=sortvar,
                                modality=modality,
                                clusterID=clusterID,
                                conditions=conditions,
                                errorRatesAndMeanRTsStats=errorRatesAndMeanRTsStats,
                                getSubjectBehavioralMeasureCIFunc=
                                 getSubjectBehavioralMeasureCIFunc,
                                subjectsAndComponents=subjectsAndComponents,
                                minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                 minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                analyzedDataFilenamePattern=
                                 analyzedDataFilenamePattern)
        if(length(cPredCorCoefsAndABMs)>0) {
            predCorCoefsAndABMs <- c(predCorCoefsAndABMs, cPredCorCoefsAndABMs)
        }
    }
    return(predCorCoefsAndABMs)
}
