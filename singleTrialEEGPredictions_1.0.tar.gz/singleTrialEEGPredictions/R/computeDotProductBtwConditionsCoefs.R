computeDotProductBtwConditionsCoefs <-
function(times1, condition1Coefs, 
                                                 times2, condition2Coefs, 
                                                 nResamples) {
    matchRes <- match(x=times1, table=times2)
    c1CommonTimeIndices <- which(!is.na(matchRes))
    c2CommonTimeIndices <- matchRes[c1CommonTimeIndices]
    if(length(c1CommonTimeIndices)>2) {
        permRes <- permuteDotProduct(x=condition1Coefs[c1CommonTimeIndices],
                                      y=condition2Coefs[c2CommonTimeIndices],
                                      nResamples=nResamples)
        dotProduct <- permRes$t0
        pValue <- sum(abs(permRes$t)>abs(permRes$t0))/length(permRes$t)
    } else {
        dotProduct <- NaN
        pValue <- NaN
    }
    return(list(dotProduct=dotProduct, pValue=pValue))
}
