printPredictionsErrorsAndBehavioralMeasuresTabularRows <-
function(df, printDFRowFunc, printSubjectSeparatorFunc, con) {
    for(i in 1:nrow(df)) {
        printDFRowFunc(df[i, ], con=con)
        if((i==nrow(df) || df[i, "subjectName"]!=df[i+1, "subjectName"])) {
            printSubjectSeparatorFunc(con)
        }
    }
}
