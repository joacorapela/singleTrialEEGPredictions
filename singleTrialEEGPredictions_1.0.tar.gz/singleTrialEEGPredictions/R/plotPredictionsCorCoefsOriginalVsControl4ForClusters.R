plotPredictionsCorCoefsOriginalVsControl4ForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   bootPairedDifferencesFunction, 
                   scFilenamePattern, 
                   oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   controlCorCoefsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        clusterCorCoefs <- plotPredictionsCorCoefsOriginalVsControl4ForConditions(
                            sortvar=sortvar,
                            modality=modality,
                            clusterID=clusterID,
                            conditions=conditions,
                            significance=significance,
                            nResamples=nResamples,
                            ciConf=ciConf,
                            annotationPattern=annotationPattern,
                            subjectsAndComponents=subjectsAndComponents,
                            bootPairedDifferencesFunction=
                             bootPairedDifferencesFunction,
                            oMinAndMaxSFPDOfBestPredictionsFilenamePattern=
                             oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                            cMinAndMaxSFPDOfBestPredictionsFilenamePattern=
                             cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                            analyzedDataFilenamePattern=
                             analyzedDataFilenamePattern,
                            controlCorCoefsFilenamePattern=
                             controlCorCoefsFilenamePattern,
                            plotFilenamePattern=plotFilenamePattern,
                            ...)
    }
}
