getANOVADataFrame2ForConditions <-
function(sortvar, modality, clusterID, conditions, modelSignificance,
                   getANOVADataForSubjectFunc,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    dataFrame <- list()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        cDataFrame <- getANOVADataFrame2ForSubjects(
                   sortvar=sortvar,
                   modality=modality,
                   clusterID=clusterID,
                   condition=condition,
                   modelSignificance=modelSignificance,
                   getANOVADataForSubjectFunc=getANOVADataForSubjectFunc,
                   subjectsAndComponents=subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern=
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        if(length(cDataFrame)>0) {
            cDataFrame["condition"] <- condition
            dataFrame <- rbind(dataFrame, cDataFrame)
        }
    }
    return(dataFrame)
}
