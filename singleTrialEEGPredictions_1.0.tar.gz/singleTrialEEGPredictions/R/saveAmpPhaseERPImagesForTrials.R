saveAmpPhaseERPImagesForTrials <-
function(subjectName, 
                                            component,
                                            peakITCFreq, 
                                            nCycles,
                                            trials, 
                                            epochEventIDs,
                                            sfpds,
                                            sfpdsOutliers,
                                            times,
                                            srate, 
                                            minTime,
                                            maxTime, 
                                            shuffleSFPDs,
                                            filename) {
    apERPImages <- prepareDataAndComputeAmplitudeAndPhaseERPImages(
                    freq=peakITCFreq,
                    nCycles=nCycles,
                    trials=trials,
                    times=times,
                    srate=srate,
                    minTime=minTime, 
                    maxTime=maxTime)
    if(shuffleSFPDs) {
        shuffleIndices <- sample(length(sfpds))
        sfpds <- sfpds[shuffleIndices]
    } else {
        shuffleIndices <- NA
    }
    apERPImages <- c(list(epochEventIDs=epochEventIDs, 
                           sfpds=sfpds, 
                           shuffleIndices=shuffleIndices,
                           peakITCFreq=peakITCFreq,
                           sfpdsOutliers=sfpdsOutliers),
                      apERPImages)
    save(apERPImages, file=filename)
}
