plotSubjectsDipolesAndCorCoefs2ForSubjects <-
function(sortvar, modality, condition, subjectsNames, clustersIDs,
                   modelSignificance, scaleLimit, pointSize,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   dipfitInfoFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(subjectName in subjectsNames) {
        show(sprintf("Processing subject %s", subjectName))
        plotSubjectsDipolesAndCorCoefs2ForSubject(
         sortvar=sortvar, 
         modality=modality, 
         condition=condition, 
         subjectName=subjectName,
         clustersIDs=clustersIDs, 
         modelSignificance=modelSignificance,
         scaleLimit=scaleLimit,
         pointSize=pointSize,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         dipfitInfoFilenamePattern=dipfitInfoFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, 
         height=height, ...)
    }
}
