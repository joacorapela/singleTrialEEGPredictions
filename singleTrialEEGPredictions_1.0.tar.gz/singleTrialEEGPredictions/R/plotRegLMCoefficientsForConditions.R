plotRegLMCoefficientsForConditions <-
function(sortvar, 
           modality, 
           clusterID,
           conditions,
           unstandardize,
           subjectsAndComponents,
           minSFPDs, maxSFPDs,
           analyzedConditionsFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotRegLMCoefficientsForSubjectsAndComponents(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         unstandardize=unstandardize,
         subjectsAndComponents=subjectsAndComponents,
         minSFPDs=minSFPDs, maxSFPDs=maxSFPDs,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         xlim=xlim,
         ...)
    }
}
