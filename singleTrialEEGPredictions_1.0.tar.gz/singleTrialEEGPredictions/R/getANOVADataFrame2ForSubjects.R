getANOVADataFrame2ForSubjects <-
function(sortvar, modality, clusterID, condition, modelSignificance,
                   getANOVADataForSubjectFunc,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    dataFrame <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, 
                  clusterID, clusterID, condition, sortvar, modality, 
                  subjectName, component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        if(!is.na(minSFPD) && !is.na(maxSFPD)) {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                             clusterID,
                                             clusterID,
                                             condition,
                                             sortvar,
                                             modality,
                                             subjectName,
                                             component,
                                             minSFPD,
                                             maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))
# if(subjectName=="av112a" && component==7) {
#     browser()
# }
            if(!is.null(analyzedData$lrtRes) &&
               analyzedData$lrtRes$pValue<modelSignificance) {
                sDataFrame <- getANOVADataForSubjectFunc(analyzedData=
                                                           analyzedData, 
                                                          minSFPD=minSFPD,
                                                          maxSFPD=maxSFPD)
                sDataFrame["subject"] <- subjectName
                sDataFrame["component"] <- component
                dataFrame <- rbind(dataFrame, sDataFrame)
            }
        }
    }
    return(dataFrame)
}
