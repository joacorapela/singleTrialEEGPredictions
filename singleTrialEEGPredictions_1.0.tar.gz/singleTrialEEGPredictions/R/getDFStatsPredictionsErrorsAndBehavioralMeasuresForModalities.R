getDFStatsPredictionsErrorsAndBehavioralMeasuresForModalities <-
function(sortvar, modalities, clustersIDs, conditions, 
                   filterSFPStatsFunc,
                   filterDFPStatsFunc, 
                   getUnselectedSFPStats, 
                   getUnselectedDFPStats, 
                   getSFPAndDFPStatsForSubjectAndComponentFunc,
                   getSFPStatsForSubjectAndComponentFunc,
                   sFPStatsForModalities, 
                   dFPStatsForSubjects,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   modelSignificance) {
    df <- data.frame()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        sFPStatsForClusters <- 
         getItemInAVShiftList(listOfItems=sFPStatsForModalities,
                               listFieldName="stats",
                               keyFieldNames=c("modality"),
                               keyFieldValues=c(modality))
        clustersDF <- 
        getDFStatsPredictionsErrorsAndBehavioralMeasuresForClusters( 
         sortvar=sortvar,
         modality=modality,
         clustersIDs=clustersIDs,
         conditions=conditions,
         filterSFPStatsFunc=filterSFPStatsFunc,
         filterDFPStatsFunc=filterDFPStatsFunc,
         getUnselectedSFPStats=getUnselectedSFPStats,
         getUnselectedDFPStats=getUnselectedDFPStats,
         getSFPAndDFPStatsForSubjectAndComponentFunc=
          getSFPAndDFPStatsForSubjectAndComponentFunc,
         getSFPStatsForSubjectAndComponentFunc=
          getSFPStatsForSubjectAndComponentFunc,
         sFPStatsForClusters=sFPStatsForClusters, 
         dFPStatsForSubjects=dFPStatsForSubjects,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         modelSignificance=modelSignificance)
        df <- rbind(df, clustersDF)
    }
    df$modality <- factor(df$modality)
    df$clusterID <- factor(df$clusterID)
    df$condition <- factor(df$condition)
    return(df)
}
