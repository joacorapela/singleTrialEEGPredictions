plotITCsForClusters <-
function(sortvar,
           modality, 
           clustersIDs, 
           conditions,
           noctave, nvoice, nCycles, 
           itcFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ylim,
           zlim,
           cuts,
           nFreqTicks) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %2d", clusterID))
        plotITCsForConditions(sortvar=sortvar, 
                                       modality=modality,
                                       clusterID=clusterID, 
                                       conditions=conditions, 
                                       noctave=noctave, 
                                       nvoice=nvoice, 
                                       nCycles=nCycles,
                                       itcFilenamePattern=
                                        itcFilenamePattern,
                                       plotsFilenamePattern=
                                        plotsFilenamePattern,
                                       xlim=xlim, 
                                       ylim=ylim, 
                                       zlim=zlim,
                                       cuts=cuts, 
                                       nFreqTicks=nFreqTicks)
    }
}
