plotMaxSFPDsForTwoConditionsForModalities <-
function(sortvar, modalities, clustersIDs, condition1, condition2,
                   nResamples, ciConf, annotationPattern, 
                   scFilenamePattern, 
                   maxSFPDsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(modality in modalities) {
        modalityMaxSFPDs <- plotMaxSFPDsForTwoConditionsForClusters(
                        sortvar=sortvar,
                        modality=modality,
                        clustersIDs=clustersIDs,
                        condition1=condition1,
                        condition2=condition2,
                        nResamples=nResamples,
                        ciConf=ciConf,
                        annotationPattern=annotationPattern,
                        scFilenamePattern=scFilenamePattern,
                        maxSFPDsFilenamePattern=
                         maxSFPDsFilenamePattern,
                        plotFilenamePattern=plotFilenamePattern,
                        ...)
    }
}
