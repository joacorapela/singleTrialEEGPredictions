getModalityAndConditionSFPDsInfo <-
function(modality, condition, 
                                                      sfpdsInfoForModalities) {
    for(i in 1:length(sfpdsInfoForModalities)) {
        if(sfpdsInfoForModalities[[i]]$modality==modality) {
            sfpdsInfoForConditions <- sfpdsInfoForModalities[[i]]$sfpdsInfo
            return(getConditionSFPDsInfo(condition=condition,
                                         sfpdsInfoForConditions=
                                          sfpdsInfoForConditions))
        }
    }
    stop(sprintf("Modality %s not found", modality))
}
