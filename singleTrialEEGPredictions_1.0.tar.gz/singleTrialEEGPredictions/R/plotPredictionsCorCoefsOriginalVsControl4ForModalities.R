plotPredictionsCorCoefsOriginalVsControl4ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, 
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   bootPairedDifferencesFunction, 
                   scFilenamePattern, 
                   oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   controlCorCoefsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(modality in modalities) {
        modalityPredictionsCorCoefs <- plotPredictionsCorCoefsOriginalVsControl4ForClusters(
                        sortvar=sortvar,
                        modality=modality,
                        clustersIDs=clustersIDs,
                        conditions=conditions,
                        significance=significance,
                        nResamples=nResamples,
                        ciConf=ciConf,
                        annotationPattern=annotationPattern,
                        bootPairedDifferencesFunction=
                         bootPairedDifferencesFunction,
                        scFilenamePattern=scFilenamePattern,
                        oMinAndMaxSFPDOfBestPredictionsFilenamePattern=
                         oMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                        cMinAndMaxSFPDOfBestPredictionsFilenamePattern=
                         cMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                        analyzedDataFilenamePattern=
                         analyzedDataFilenamePattern,
                        controlCorCoefsFilenamePattern=
                         controlCorCoefsFilenamePattern,
                        plotFilenamePattern=plotFilenamePattern,
                        ...)
    }
}
