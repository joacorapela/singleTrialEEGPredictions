computePeakAbsTimeDifBtwClustersCoefsForModalities <-
function(sortvar, modalities, clustersIDs1, clustersIDs2, conditions,
                   modelSignificance, srate, lowpassFilterOrder, margin,
                   minPeakTime, onlySignificantPeaks,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        res <- 
         computePeakAbsTimeDifBtwClustersCoefsForClusters(
          sortvar=sortvar,
          modality=modality,
          clustersIDs1=clustersIDs1,
          clustersIDs2=clustersIDs2,
          conditions=conditions,
          modelSignificance=modelSignificance,
          srate=srate,
          lowpassFilterOrder=lowpassFilterOrder,
          margin=margin,
          minPeakTime=minPeakTime,
          onlySignificantPeaks=onlySignificantPeaks,
          scFilenamePattern=scFilenamePattern,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          analyzedDataFilenamePattern=
           analyzedDataFilenamePattern, 
          ...)
        answer <- rbind(answer, 
                         cbind(modality=rep(modality, times=nrow(res)), res))
    }
    return(answer)
}
