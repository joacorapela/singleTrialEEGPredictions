plotPredictionsCorCoefsForTwoConditionsForModalities <-
function(sortvar, modalities, clustersIDs, condition1, condition2,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   bootPairedDifferencesFunction,
                   scFilenamePattern, 
                   analyzedDataFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   unAttMinAndMaxSFPDOfBestPredictionsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(modality in modalities) {
        modalityPredictionsCorCoefs <- plotPredictionsCorCoefsForTwoConditionsForClusters(
                        sortvar=sortvar,
                        modality=modality,
                        clustersIDs=clustersIDs,
                        condition1=condition1,
                        condition2=condition2,
                        minSFPD=minSFPD,
                        maxSFPD=maxSFPD,
                        significance=significance,
                        nResamples=nResamples,
                        ciConf=ciConf,
                        annotationPattern=annotationPattern,
                        bootPairedDifferencesFunction=
                         bootPairedDifferencesFunction,
                        scFilenamePattern=scFilenamePattern,
                        analyzedDataFilenamePattern=
                         analyzedDataFilenamePattern,
                        minAndMaxSFPDOfBestPredictionsFilenamePattern=
                         minAndMaxSFPDOfBestPredictionsFilenamePattern,
                        plotFilenamePattern=plotFilenamePattern,
                        ...)
    }
}
