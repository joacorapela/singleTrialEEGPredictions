plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForModalities <-
function(sortvar, modalities, clustersIDs, conditions, 
                   modelSignificance,
                   annotationPattern, 
                   scFilenamePattern, 
                   analyzedConditionsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   behavioralMeasuresFilenamePattern,
                   plotsFilenamePattern, 
                   xCorCoefAnnotation, yCorCoefAnnotation, 
                   hjust, vjust,
                   sizeLabels, sizeAnnotations, xlab, ylab, main, 
                   width, height, ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotPredictionsCorCoefsVsAveragedBehavioralMeasuresToDistributeForClusters(
         sortvar=sortvar, 
         modality=modality, 
         clustersIDs=clustersIDs, 
         conditions=conditions, 
         modelSignificance=modelSignificance,
         annotationPattern=annotationPattern, 
         scFilenamePattern=scFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         behavioralMeasuresFilenamePattern=behavioralMeasuresFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         xCorCoefAnnotation=xCorCoefAnnotation, 
         yCorCoefAnnotation=yCorCoefAnnotation, 
         hjust=hjust, vjust=vjust,
         sizeLabels=sizeLabels, 
         sizeAnnotations=
         sizeAnnotations, 
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         width=width, 
         height=height, ...)
    }
}
