getPredictionsAndSFPDsBySubjectForClusters <-
function(sortvar, subject, modality, clustersIDs, conditions, 
                   modelSignificance,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        indices <- which(subjectsAndComponents[,1]==subject)
        components <- subjectsAndComponents[indices,2]
        if(length(components)>0) {
            cDataSet <- getPredictionsAndSFPDsBySubjectForConditions(
                         sortvar=sortvar,
                         subject=subject,
                         modality=modality,
                         clusterID=clusterID,
                         conditions=conditions,
                         modelSignificance=modelSignificance, 
                         components=components,
                         minAndMaxSFPDOfBestPredictionsFilenamePattern=
                          minAndMaxSFPDOfBestPredictionsFilenamePattern,
                         analyzedDataFilenamePattern=
                          analyzedDataFilenamePattern,
                         ...)
            datasets <- c(datasets, cDataSet)
        }
    }
    return(datasets)
}
