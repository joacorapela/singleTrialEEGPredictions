getDFStatsPredictionsErrorsAndBehavioralMeasuresForConditions <-
function(sortvar, modality, clusterID, conditions,
                   filterSFPStatsFunc,
                   filterDFPStatsFunc, 
                   getUnselectedSFPStats, 
                   getUnselectedDFPStats, 
                   getSFPAndDFPStatsForSubjectAndComponentFunc,
                   getSFPStatsForSubjectAndComponentFunc,
                   sFPStatsForConditions,
                   dFPStatsForSubjects, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   modelSignificance) {
    df <- data.frame()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        sFPStatsForSubjects <- 
         getItemInAVShiftList(listOfItems=sFPStatsForConditions,
                               listFieldName="stats",
                               keyFieldNames=c("condition"),
                               keyFieldValues=c(condition))
        if(length(sFPStatsForSubjects)>0) {
            subjectsDF <- 
            getDFStatsPredictionsErrorsAndBehavioralMeasuresForSubjectsAndComponents( 
             sortvar=sortvar,
             modality=modality,
             clusterID=clusterID,
             condition=condition,
             filterSFPStatsFunc=filterSFPStatsFunc,
             filterDFPStatsFunc=filterDFPStatsFunc,
             getUnselectedSFPStats=getUnselectedSFPStats,
             getUnselectedDFPStats=getUnselectedDFPStats,
             getSFPAndDFPStatsForSubjectAndComponentFunc=
              getSFPAndDFPStatsForSubjectAndComponentFunc,
             getSFPStatsForSubjectAndComponentFunc=
              getSFPStatsForSubjectAndComponentFunc,
             sFPStatsForSubjects=sFPStatsForSubjects,
             dFPStatsForSubjects=dFPStatsForSubjects,
             minAndMaxSFPDOfBestPredictionsFilenamePattern=
              minAndMaxSFPDOfBestPredictionsFilenamePattern,
             analyzedDataFilenamePattern=analyzedDataFilenamePattern,
             modelSignificance=modelSignificance)
            df <- rbind(df, subjectsDF)
        }
    }
    return(df)
}
