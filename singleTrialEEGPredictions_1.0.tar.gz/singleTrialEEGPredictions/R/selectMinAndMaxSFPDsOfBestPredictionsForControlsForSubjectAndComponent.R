selectMinAndMaxSFPDsOfBestPredictionsForControlsForSubjectAndComponent <-
function(sortvar, modality, clusterID, condition, subjectName, component,
                   minSFPDs, maxSFPDs, corCoefsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    minAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, 
              clusterID, clusterID, condition, sortvar, modality, 
              subjectName, component)
    largestMedianCorCoef <- -Inf
    selectedMinSFPD <- minSFPDs[1]
    selectedMaxSFPD <- maxSFPDs[1]
# if(subjectName=="av112a" && component==11) {
#     browser()
# }
    for(i in 1:length(minSFPDs)) {
        minSFPD <- minSFPDs[i]
        for(j in 1:length(maxSFPDs)) {
            maxSFPD <- maxSFPDs[j]
            corCoefsFilename <- 
             sprintf(corCoefsFilenamePattern, clusterID, clusterID, condition, 
                                              sortvar, modality, 
                                              subjectName, component,
                                              minSFPD, maxSFPD)
            if(!file.exists(corCoefsFilename)) {
                next
            }
            corCoefs <- get(load(corCoefsFilename))
            medianCorCoefs <- median(corCoefs)
            if(medianCorCoefs>largestMedianCorCoef) {
                largestMedianCorCoef <- medianCorCoefs
                selectedMinSFPD <- minSFPD
                selectedMaxSFPD <- maxSFPD
            }
        }
    }
    writeLines(c(toString(selectedMinSFPD), toString(selectedMaxSFPD)), 
                con=minAndMaxSFPDOfBestPredictionsFilename)
}
