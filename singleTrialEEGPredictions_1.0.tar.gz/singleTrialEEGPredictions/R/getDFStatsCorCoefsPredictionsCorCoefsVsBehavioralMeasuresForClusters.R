getDFStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasuresForClusters <-
function(sortvar, modality, clustersIDs, conditions, filterFunc,
                   getDFStatsForConditionFunc, statsFilenamePattern) {
    dataFrame <- c()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        cDataFrame <-
         getDFStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasuresForConditions(
          sortvar=sortvar, 
          modality=modality, 
          clusterID=clusterID,
          conditions=conditions,
          filterFunc=filterFunc,
          getDFStatsForConditionFunc=getDFStatsForConditionFunc,
          statsFilenamePattern=statsFilenamePattern)
        if(length(cDataFrame)>0) {
            cDataFrame["clusterID"] <- clusterID
            dataFrame <- rbind(dataFrame, cDataFrame)
        }
    }
    return(dataFrame)
}
