preProcessPhaseERPImagesForCondition <-
function(sortvar, 
           modality, 
           clusterID, 
           condition, 
           subjectsAndComponents,
           srate,
           clipFrom, clipTo,
           alignmentSignificance,
           plotSteps,
           averageTrialsWinSize,
           plotsFilenamePattern,
           width, height,
           xlim, zlim,
           phaseERPImageFilenamePattern,
           preProcessedPhaseERPIFilenamePattern) {
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", 
                     subjectName, component))
        if(plotSteps) {
            condPlotsFilenamePattern <- sprintf(plotsFilenamePattern, 
                                                 clusterID, 
                                                 condition, 
                                                 sortvar, 
                                                 modality, 
                                                 subjectName,
                                                 component)
        }
        phaseERPImageFilename <- sprintf(phaseERPImageFilenamePattern, 
                                          clusterID, 
                                          condition, 
                                          sortvar, 
                                          modality, 
                                          subjectName,
                                          component)
        loadPhaseERPImageRes <- get(load(phaseERPImageFilename))
        preProcessedERPI <- 
         preProcessPhaseERPI(phaseERPImage=loadPhaseERPImageRes$phaseERPImage, 
                              times=loadPhaseERPImageRes$times, 
                              sfpds=loadPhaseERPImageRes$sfpds, 
                              sfpdsOutliers=loadPhaseERPImageRes$sfpdsOutliers,
                              srate=srate, 
                              clipFrom=clipFrom, clipTo=clipTo, 
                              alignmentSignificance=alignmentSignificance,
                              plotSteps=plotSteps, 
                              averageTrialsWinSize=averageTrialsWinSize, 
                              plotsFilenamePattern=
                               condPlotsFilenamePattern, 
                              width=width, height=height, xlim=xlim, 
                              zlim=zlim)
        preProcessedERPI <- c(preProcessedERPI, 
                               list(sfpds=loadPhaseERPImageRes$sfpds,
                                     epochEventIDs=
                                      loadPhaseERPImageRes$epochEventIDs,
                                     peakITCFreq=
                                      loadPhaseERPImageRes$peakITCFreq,
                                     shuffleIndices=
                                      loadPhaseERPImageRes$shuffleIndices))
        preProcessedPhaseERPIFilename <- 
         sprintf(preProcessedPhaseERPIFilenamePattern, clusterID, 
                                                           condition, 
                                                           sortvar, 
                                                           modality, 
                                                           subjectName,
                                                           component)
        save(preProcessedERPI, file=preProcessedPhaseERPIFilename)
    }
}
