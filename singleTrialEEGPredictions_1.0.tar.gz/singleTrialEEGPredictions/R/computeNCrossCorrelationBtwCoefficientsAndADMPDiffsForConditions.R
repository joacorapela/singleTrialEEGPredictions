computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForConditions <-
function(sortvar, modality, clusterID, conditions,
                   earlyFromPercentage, earlyToPercentage,
                   lateFromPercentage, lateToPercentage,
                   modelSignificance, minTimeSpanCoefsMS, srate,
                   subjectsAndComponents, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   preProcessedPhaseERPIFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        res <- 
         computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForSubjectsAndComponents(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          condition=condition,
          earlyFromPercentage=earlyFromPercentage,
          earlyToPercentage=earlyToPercentage,
          lateFromPercentage=lateFromPercentage,
          lateToPercentage=lateToPercentage,
          modelSignificance=modelSignificance,
          subjectsAndComponents=subjectsAndComponents,
          minTimeSpanCoefsMS=minTimeSpanCoefsMS,
          srate=srate,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          preProcessedPhaseERPIFilenamePattern,
          analyzedDataFilenamePattern=analyzedDataFilenamePattern,
          ...)
        answer <- rbind(answer, 
                         cbind(condition=rep(condition, times=nrow(res)), res))
    }
    return(answer)
}
