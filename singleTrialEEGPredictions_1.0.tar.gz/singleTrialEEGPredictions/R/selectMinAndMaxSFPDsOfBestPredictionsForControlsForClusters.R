selectMinAndMaxSFPDsOfBestPredictionsForControlsForClusters <-
function(sortvar, modality, clustersIDs, conditions, scFilenamePattern,
                   minSFPDs, maxSFPDs, corCoefsFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %2d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        selectMinAndMaxSFPDsOfBestPredictionsForControlsForConditions(sortvar=sortvar, 
                                        modality=modality, 
                                        clusterID=clusterID, 
                                        conditions=conditions, 
                                        subjectsAndComponents=
                                         subjectsAndComponents,
                                        minSFPDs=minSFPDs, 
                                        maxSFPDs=maxSFPDs, 
                                        corCoefsFilenamePattern=
                                         corCoefsFilenamePattern,
                                        minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                         minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
