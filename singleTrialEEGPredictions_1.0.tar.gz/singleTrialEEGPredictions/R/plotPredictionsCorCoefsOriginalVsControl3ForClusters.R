plotPredictionsCorCoefsOriginalVsControl3ForClusters <-
function(sortvar, modality, clustersIDs, conditions, minSFPD, maxSFPD,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   scFilenamePattern, 
                   analyzedDataFilenamePattern,
                   controlCorCoefsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        clusterCorCoefs <- plotPredictionsCorCoefsOriginalVsControl3ForConditions(
                            sortvar=sortvar,
                            modality=modality,
                            clusterID=clusterID,
                            conditions=conditions,
                            minSFPD=minSFPD,
                            maxSFPD=maxSFPD,
                            significance=significance,
                            nResamples=nResamples,
                            ciConf=ciConf,
                            annotationPattern=annotationPattern,
                            subjectsAndComponents=subjectsAndComponents,
                            analyzedDataFilenamePattern=
                             analyzedDataFilenamePattern,
                            controlCorCoefsFilenamePattern=
                             controlCorCoefsFilenamePattern,
                            plotFilenamePattern=plotFilenamePattern,
                            ...)
    }
}
