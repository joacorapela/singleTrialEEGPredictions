saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForConditions <-
function(sortvar, modality, clusterID, conditions, nResamples, conf,
                   modelSignificance, errorRatesAndMeanRTsStats,
                   getSubjectBehavioralMeasureCIFunc, 
                   subjectsAndComponents, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, 
                   statsFilenamePattern, ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        saveStatsPredictionsCorCoefsVsAveragedBehavioralMeasures2ForSubjects(
         sortvar=sortvar,
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         nResamples=nResamples,  
         conf=conf,
         modelSignificance=modelSignificance,
         errorRatesAndMeanRTsStats=errorRatesAndMeanRTsStats,
         getSubjectBehavioralMeasureCIFunc=getSubjectBehavioralMeasureCIFunc,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         statsFilenamePattern=statsFilenamePattern,
         ...)
    }
}
