plotRegLMCoefficientsAtBestMinAndMaxSFPDsForConditions <-
function(sortvar, 
           modality, 
           clusterID,
           conditions,
           unstandardize,
           modelSignificance,
           subjectsAndComponents,
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern,
           plotsFilenamePattern,
           ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotRegLMCoefficientsAtBestMinAndMaxSFPDsForSubjectsAndComponents(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         unstandardize=unstandardize,
         modelSignificance=modelSignificance,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         ...)
    }
}
