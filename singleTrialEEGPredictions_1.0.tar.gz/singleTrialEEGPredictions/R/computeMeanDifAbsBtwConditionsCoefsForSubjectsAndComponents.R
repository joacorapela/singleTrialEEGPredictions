computeMeanDifAbsBtwConditionsCoefsForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition1, condition2, 
                   modelSignificance, nResamples, 
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    subjectsNames <- c()
    components <- c()
    meanDifAbs <- c()
    pValues <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
         res <- 
          computeMeanDifAbsBtwConditionsCoefsForSubjectAndComponent(
           sortvar=sortvar,
           modality=modality,
           clusterID=clusterID,
           condition1=condition1,
           condition2=condition2,
           subjectName=subjectName,
           component=component,
           modelSignificance=modelSignificance,
           nResamples=nResamples,
           minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern=analyzedDataFilenamePattern,
           ...)
        if(!is.null(res)) {
            subjectsNames <- c(subjectsNames, subjectName)
            components <- c(components, component)
            meanDifAbs <- c(meanDifAbs, res[1])
            pValues <- c(pValues, res[2])
        }
    }
    if(length(subjectsNames)>0) {
        return(data.frame(subjectName=subjectsNames, component=components,
                                                     meanDifAbs=meanDifAbs,
                                                     pValue=pValues))
    } else {
        return(data.frame())
    }
}
