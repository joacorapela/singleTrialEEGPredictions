getPredictionsAndSFPDsBySubjectForModalities <-
function(sortvar, subject, modalities, clustersIDs, conditions, 
                   modelSignificance,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        mDataSet <- getPredictionsAndSFPDsBySubjectForClusters(
                     sortvar=sortvar,
                     subject=subject,
                     modality=modality,
                     clustersIDs=clustersIDs,
                     conditions=conditions,
                     modelSignificance=modelSignificance, 
                     scFilenamePattern=scFilenamePattern,
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, mDataSet)
    }
    return(datasets)
}
