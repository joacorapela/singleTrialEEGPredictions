computeDotProductBtwConditionsCoefsForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition1, condition2, 
                   significance, nResamples, 
                   subjectsAndComponents=subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    dotProducts <- c()
    pValues <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
         res <- 
          computeDotProductBtwConditionsCoefsForSubjectAndComponent(
           sortvar=sortvar,
           modality=modality,
           clusterID=clusterID,
           condition1=condition1,
           condition2=condition2,
           subjectName=subjectName,
           component=component,
           significance=significance,
           nResamples=nResamples,
           minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern=analyzedDataFilenamePattern,
           ...)
        dotProducts <- c(dotProducts, res[1])
        pValues <- c(pValues, res[2])
    }
    return(data.frame(subjectName=subjectsAndComponents[,"subjectName"],
                       component=subjectsAndComponents[,"component"], 
                       dotProduct=dotProducts,
                       pValue=pValues))
}
