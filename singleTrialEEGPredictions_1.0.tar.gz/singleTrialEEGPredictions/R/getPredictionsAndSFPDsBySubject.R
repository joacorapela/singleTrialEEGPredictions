getPredictionsAndSFPDsBySubject <-
function(sortvar, subjects, modalities, clustersIDs, conditions, 
                   modelSignificance, 
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(i in 1:length(subjects)) {
        show(sprintf("Processing subject %s", subjects[i]))
        sDataSet <- getPredictionsAndSFPDsBySubjectForModalities(
                     sortvar=sortvar,
                     subject=subjects[i],
                     modalities=modalities,
                     clustersIDs=clustersIDs,
                     conditions=conditions,
                     modelSignificance=modelSignificance, 
                     scFilenamePattern=scFilenamePattern,
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, list(list(subjectName=subjects[i], 
                                           datasets=sDataSet)))
    }
    return(datasets)
}
