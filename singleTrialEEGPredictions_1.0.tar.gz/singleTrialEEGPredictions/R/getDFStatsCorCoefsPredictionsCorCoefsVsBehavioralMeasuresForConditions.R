getDFStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasuresForConditions <-
function(sortvar, modality, clusterID, conditions, filterFunc,
                   getDFStatsForConditionFunc, statsFilenamePattern) {
    dataFrame <- c()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        statsFilename <- sprintf(statsFilenamePattern, clusterID, clusterID, 
                                                       condition, sortvar, 
                                                       modality)
        stats <- get(load(statsFilename))
        cDataFrame <- NULL
        if(filterFunc(stats=stats)) {
            cDataFrame <- getDFStatsForConditionFunc(stats=stats)
        }
        if(!is.null(cDataFrame)) {
            cDataFrame["condition"] <- condition
            dataFrame <- rbind(dataFrame, cDataFrame)
        }
    }
    return(dataFrame)
}
