analyzeDataRegularizedRegressionForConditions <-
function(modality, sortvar, clusterID, conditions, 
                    subjectsAndComponents,
                    preProcessedPhaseERPIFilenamePattern, 
                    analyzedConditionsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, interactions, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, computeCoefsCIs, maxIter, convergenceTol,
                    nResamplesCoefs, nResamplesPredictions, 
                    confCIs) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        analyzeDataRegularizedRegressionForSubjectsAndComponents(
         modality=modality, 
         sortvar=sortvar, 
         clusterID=clusterID, 
         condition=condition, 
         subjectsAndComponents=subjectsAndComponents,
         preProcessedPhaseERPIFilenamePattern=
          preProcessedPhaseERPIFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         interactions=interactions,
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, computeCoefsCIs=computeCoefsCIs,
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nResamplesCoefs=nResamplesCoefs,
         nResamplesPredictions=nResamplesPredictions, 
         confCIs=confCIs)
    }
}
