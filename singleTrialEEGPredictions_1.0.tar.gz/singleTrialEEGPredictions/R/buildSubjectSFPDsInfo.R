buildSubjectSFPDsInfo <-
function(subjectName, modalities, conditions, 
                                               sfpdsInfoFilenamePattern) {
    sfpdsInfo <- list()
    for(modality in modalities) {
        show(sprintf('Processing modality %s', modality))
        modalitySFPDsInfo <- buildModalitySFPDsInfo(
                              subjectName=subjectName, 
                              modality=modality,
                              conditions=conditions,
                              sfpdsInfoFilenamePattern=
                               sfpdsInfoFilenamePattern)
        sfpdsInfo <- c(sfpdsInfo, list(list(modality=modality, 
                                             sfpdsInfo=modalitySFPDsInfo)))
    }
    return(sfpdsInfo)
}
