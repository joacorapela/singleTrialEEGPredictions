getConditionSFPDsInfo <-
function(condition, sfpdsInfoForConditions) {
    for(i in 1:length(sfpdsInfoForConditions)) {
        if(sfpdsInfoForConditions[[i]]$condition==condition) {
            return(sfpdsInfoForConditions[[i]]$sfpdsInfo)
        }
    }
    stop(sprintf("Condition %s not found", condition))
}
