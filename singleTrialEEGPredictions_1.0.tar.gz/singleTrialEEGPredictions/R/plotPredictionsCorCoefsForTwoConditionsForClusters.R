plotPredictionsCorCoefsForTwoConditionsForClusters <-
function(sortvar, modality, clustersIDs, condition1, condition2, 
                   minSFPD, maxSFPD,
                   significance,
                   nResamples, ciConf, annotationPattern, 
                   bootPairedDifferencesFunction,
                   scFilenamePattern, 
                   analyzedDataFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   plotFilenamePattern,
                   ...) {
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID, scFilename)
        clusterCorCoefs <- 
         plotPredictionsCorCoefsForTwoConditionsForSubjectsAndComponents(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          condition1=condition1,
          condition2=condition2,
          minSFPD=minSFPD,
          maxSFPD=maxSFPD,
          significance=significance,
          nResamples=nResamples,
          ciConf=ciConf,
          annotationPattern=annotationPattern,
          bootPairedDifferencesFunction=bootPairedDifferencesFunction,
          subjectsAndComponents=subjectsAndComponents,
          analyzedDataFilenamePattern=
           analyzedDataFilenamePattern,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          plotFilenamePattern=plotFilenamePattern,
          ...)
    }
}
