printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, filterFunc,
                   getConditionStatsDescFunc, statsFilenamePattern, con) {
    for(modality in modalities) {
        printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForClusters(
         sortvar=sortvar, 
         modality=modality, 
         clustersIDs=clustersIDs,
         conditions=conditions,
         filterFunc=filterFunc,
         getConditionStatsDescFunc=getConditionStatsDescFunc,
         statsFilenamePattern=statsFilenamePattern,
         con=con)
    }
}
