plotRegLMCoefficientsAtBestMinAndMaxSFPDsForSubjectsAndComponents <-
function(sortvar, 
           modality, 
           clusterID, 
           condition, 
           unstandardize,
           modelSignificance,
           subjectsAndComponents,
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern,
           plotsFilenamePattern,
           ...) { 
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and comonent %02d", 
                     subjectName, component))
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID,
                  clusterID, condition, sortvar, modality, subjectName, 
                  component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        plotFilename <- sprintf(plotsFilenamePattern, 
                                 clusterID,
                                 clusterID,
                                 condition,
                                 sortvar,
                                 modality,
                                 subjectName,
                                 component)
        if(!is.na(minSFPD) && !is.na(maxSFPD)) {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern, 
                                             clusterID, clusterID, condition, 
                                             sortvar, modality, 
                                             subjectName, component,
                                             minSFPD, maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))
            meanTimeRegressors <- analyzedData$meanTimeRegressors
            if(!is.infinite(modelSignificance) ||
               (!is.null(analyzedData$lrtRes) &&
                analyzedData$lrtRes$pValue<modelSignificance)) {
                coefsCIs <- analyzedData$coefsCIs
                if(unstandardize) {
                    scale <- attr(analayzedData$data, "scaled:scale")
                    scaleY <- scale[1]
                    scaleX <- scale[-1]
                    center <- attr(analayzedData$data, "scaled:center")
                    centerY <- center[1]
                    centerX <- center[-1]
                    coefsCIs <- unstandardizeCoefs(standardizedCoefs=coefsCIs, 
                                                    centerX=centerX,
                                                    scaleX=scaleX,
                                                    centerY=centerY,
                                                    scaleY=scaleY)
                }
                plotRegLMCoefficients(coefsCIs=coefsCIs,
                                       times=analyzedData$times,
                                       itc=analyzedData$itc,
                                       meanDirection=analyzedData$meanDirection,
                                       ...)
            } else {
                plot(getEmptyPlot())
            }
        } else {
            plot(getEmptyPlot())
        }
        ggsave(filename=plotFilename)
    }
}
