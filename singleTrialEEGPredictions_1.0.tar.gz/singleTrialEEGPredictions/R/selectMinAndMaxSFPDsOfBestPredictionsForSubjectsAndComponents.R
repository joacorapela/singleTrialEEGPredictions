selectMinAndMaxSFPDsOfBestPredictionsForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition, subjectsAndComponents, 
                   minSFPDs, maxSFPDs, analyzedDataFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                                          component))
        selectMinAndMaxSFPDsOfBestPredictionsForSubjectAndComponent(sortvar=sortvar, 
                                                 modality=modality, 
                                                 clusterID=clusterID, 
                                                 condition=condition, 
                                                 subjectName=subjectName, 
                                                 component=component, 
                                                 minSFPDs=minSFPDs, 
                                                 maxSFPDs=maxSFPDs, 
                                                 analyzedDataFilenamePattern=
                                                  analyzedDataFilenamePattern, 
                                                 minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                                  minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
