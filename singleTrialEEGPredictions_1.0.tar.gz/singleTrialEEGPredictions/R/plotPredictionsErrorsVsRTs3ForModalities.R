plotPredictionsErrorsVsRTs3ForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                   getStatsCorCoefAnnotationFunction,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, 
                   maxDFPD,
                   nResamples, conf,
                   subjectsAndComponents,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotPredictionsErrorsVsRTs3ForClusters(sortvar=sortvar, 
                                                modality=modality,
                                                clustersIDs=clustersIDs, 
                                                conditions=conditions,
                                                getStatsCorCoefAnnotationFunction=
                                                 getStatsCorCoefAnnotationFunction,
                                                dsAndPreviousSTDsInfo=
                                                 dsAndPreviousSTDsInfo,
                                                rtsInfo=rtsInfo,
                                                dfpdsInfo=dfpdsInfo,
                                                maxRT=maxRT,
                                                maxDFPD=maxDFPD,
                                                nResamples=nResamples, 
                                                conf=conf,
                                                subjectsAndComponents=
                                                 subjectsAndComponents,
                                                scFilenamePattern=scFilenamePattern,
                                                minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                                 minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                                analyzedDataFilenamePattern=
                                                 analyzedDataFilenamePattern,
                                                plotsFilenamePattern=
                                                 plotsFilenamePattern,
                                                width=width, 
                                                height=height,
                                               ...)
    }
}
