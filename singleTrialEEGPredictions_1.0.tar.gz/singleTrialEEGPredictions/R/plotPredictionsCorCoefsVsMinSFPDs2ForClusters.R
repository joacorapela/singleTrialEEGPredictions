plotPredictionsCorCoefsVsMinSFPDs2ForClusters <-
function(sortvar, modality, clustersIDs, conditions, minSFPDs, maxSFPD,
                   nResamples, modelSignificance, rConf,
                   subjectsAndComponents, 
                   analyzedConditionsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        plotPredictionsCorCoefsVsMinSFPDs2ForConditions(
         sortvar=sortvar, 
         modality=modality, 
         clusterID=clusterID, 
         conditions=conditions, 
         minSFPDs=minSFPDs,
         maxSFPD=maxSFPD,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         rConf=rConf,
         subjectsAndComponents=subjectsAndComponents,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern, 
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         ...)
    }
}
