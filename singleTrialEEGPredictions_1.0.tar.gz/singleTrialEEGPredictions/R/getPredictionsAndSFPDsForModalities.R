getPredictionsAndSFPDsForModalities <-
function(sortvar, modalities, clustersIDs, conditions, 
                   modelSignificance,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        mDataSet <- getPredictionsAndSFPDsForClusters(
                     sortvar=sortvar,
                     modality=modality,
                     clustersIDs=clustersIDs,
                     conditions=conditions,
                     modelSignificance=modelSignificance, 
                     scFilenamePattern=scFilenamePattern,
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, mDataSet)
    }
    return(datasets)
}
