getConditionDFPDsForSTDs <-
function(condition, dfpdsForSTDsInfoForConditions) {
    for(i in 1:length(dfpdsForSTDsInfoForConditions)) {
        if(dfpdsForSTDsInfoForConditions[[i]]$condition==condition) {
            return(dfpdsForSTDsInfoForConditions[[i]]$dfpdsForSTDsInfo)
        }
    }
    stop(sprintf("Condition %s not found", condition))
}
