getANOVADataFrame2ForClusters <-
function(sortvar, modality, clustersIDs, conditions, modelSignificance,
                   getANOVADataForSubjectFunc,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    dataFrame <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        cDataFrame <- getANOVADataFrame2ForConditions(
                   sortvar=sortvar,
                   modality=modality,
                   clusterID=clusterID,
                   conditions=conditions,
                   modelSignificance=modelSignificance,
                   getANOVADataForSubjectFunc=getANOVADataForSubjectFunc,
                   subjectsAndComponents=subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern=
                    minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern=
                    analyzedDataFilenamePattern)
        if(length(cDataFrame)>0) {
            cDataFrame["clusterID"] <- clusterID
            dataFrame <- rbind(dataFrame, cDataFrame)
        }
    }
    return(dataFrame)
}
