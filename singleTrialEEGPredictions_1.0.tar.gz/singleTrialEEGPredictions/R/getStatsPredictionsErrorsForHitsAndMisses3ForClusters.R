getStatsPredictionsErrorsForHitsAndMisses3ForClusters <-
function(sortvar, modality, clustersIDs, conditions, modelSignificance,
                   dsAndPreviousSTDsInfo,
                   rtsInfo, dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD,
                   nResamples, conf, minN,
                   subjectsAndComponents,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    stats <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        if(is.null(subjectsAndComponents)) {
            scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
            if(is.null(scFilename)) {
                stop("arguments subjectsAndComponents or scFilenamePattern should be provided")
            }
            subjectsAndComponentsInCluster <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                                scFilename=scFilename)
        } else {
            subjectsAndComponentsInCluster <- subjectsAndComponents
        }
        stats <- 
         c(stats, 
            list(list(clusterID=clusterID, 
                       stats=getStatsPredictionsErrorsForHitsAndMisses3ForConditions(
                              sortvar=sortvar,
                              modality=modality,
                              clusterID=clusterID,
                              conditions=conditions,
                              modelSignificance=modelSignificance,
                              dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                              rtsInfo=rtsInfo,
                              dfpdsInfo=dfpdsInfo,
                              maxRT=maxRT,
                              maxSTD_D_delay=maxSTD_D_delay,
                              maxDFPD=maxDFPD,
                              nResamples=nResamples,
                              conf=conf,
                              minN=minN,
                              subjectsAndComponents=subjectsAndComponentsInCluster,
                              minAndMaxSFPDOfBestPredictionsFilenamePattern=
                               minAndMaxSFPDOfBestPredictionsFilenamePattern,
                              analyzedDataFilenamePattern=
                               analyzedDataFilenamePattern))))
    }
    return(stats)
}
