plotMediansOfPredictionsErrorsForHitsAndMisses2ForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                   getStatsDifAnnotationFunction,
                   rtsForSTDsInfo,
                   dfpdsForSTDsInfo,
                   maxRT, 
                   maxDFPD, 
                   nResamples, conf,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing clusterID %s", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        plotMediansOfPredictionsErrorsForHitsAndMisses2ForConditions(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID, 
         conditions=conditions,
         getStatsDifAnnotationFunction=getStatsDifAnnotationFunction,
         rtsForSTDsInfo=rtsForSTDsInfo,
         dfpdsForSTDsInfo=dfpdsForSTDsInfo,
         maxRT=maxRT,
         maxDFPD=maxDFPD,
         nResamples=nResamples,
         conf=conf,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         ...)
    }
}
