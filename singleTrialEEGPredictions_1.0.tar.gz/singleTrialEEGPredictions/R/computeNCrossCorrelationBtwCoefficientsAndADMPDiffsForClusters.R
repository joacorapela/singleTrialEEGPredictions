computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForClusters <-
function(sortvar, modality, clustersIDs, conditions,
                   earlyFromPercentage, earlyToPercentage,
                   lateFromPercentage, lateToPercentage,
                   modelSignificance, minTimeSpanCoefsMS, srate,
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   preProcessedPhaseERPIFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %02d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        res <- 
         computeNCrossCorrelationBtwCoefficientsAndADMPDiffsForConditions(
          sortvar=sortvar,
          modality=modality,
          clusterID=clusterID,
          conditions=conditions,
          earlyFromPercentage=earlyFromPercentage,
          earlyToPercentage=earlyToPercentage,
          lateFromPercentage=lateFromPercentage,
          lateToPercentage=lateToPercentage,
          modelSignificance=modelSignificance,
          minTimeSpanCoefsMS=minTimeSpanCoefsMS,
          srate=srate,
          subjectsAndComponents=subjectsAndComponents,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          preProcessedPhaseERPIFilenamePattern,
          analyzedDataFilenamePattern=analyzedDataFilenamePattern,
          ...)
        answer <- rbind(answer, 
                         cbind(clusterID=rep(clusterID, times=nrow(res)), res))
    }
    return(answer)
}
