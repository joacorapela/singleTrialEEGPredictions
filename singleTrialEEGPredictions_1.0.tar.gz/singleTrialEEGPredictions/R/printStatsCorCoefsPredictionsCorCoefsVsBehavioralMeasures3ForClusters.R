printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForClusters <-
function(sortvar, modality, clustersIDs, conditions, filterFunc, 
                   getConditionStatsDescFunc, statsFilenamePattern, con) {
    for(clusterID in clustersIDs) {
        printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForConditions(
         sortvar=sortvar, 
         modality=modality, 
         clusterID=clusterID,
         conditions=conditions,
         filterFunc=filterFunc,
         getConditionStatsDescFunc=getConditionStatsDescFunc,
         statsFilenamePattern=statsFilenamePattern,
         con=con)
    }
}
