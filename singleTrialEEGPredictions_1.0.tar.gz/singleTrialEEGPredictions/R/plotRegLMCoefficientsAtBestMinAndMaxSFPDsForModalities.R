plotRegLMCoefficientsAtBestMinAndMaxSFPDsForModalities <-
function(sortvar, 
           modalities, 
           clustersIDs,
           conditions,
           unstandardize,
           modelSignificance,
           subjectsAndComponents,
           scFilenamePattern,
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern,
           plotsFilenamePattern,
           ...) {
    if(!is.null(subjectsAndComponents) && !is.null(scFilenamePattern)) {
        warning("Both subjectsAndComponents and scFilenamePattern are given.  Using only subjectsAndComponents")
    }
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotRegLMCoefficientsAtBestMinAndMaxSFPDsForClusters(
         sortvar=sortvar, 
         modality=modality,
         clustersIDs=clustersIDs, 
         conditions=conditions,
         unstandardize=unstandardize,
         modelSignificance=modelSignificance,
         subjectsAndComponents=subjectsAndComponents,
         scFilenamePattern=scFilenamePattern,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         ...)
    }
}
