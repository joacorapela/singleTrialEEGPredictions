printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForCondition <-
function(sortvar, modality, clusterID, condition, filterFunc, 
                   getConditionStatsDescFunc, statsFilenamePattern, con) {
    statsFilename <- sprintf(statsFilenamePattern, clusterID, clusterID, 
                                                   condition, sortvar, modality)
    stats <- get(load(statsFilename))
    if(filterFunc(stats=stats)) {
        desc <- getConditionStatsDescFunc(stats=stats)
        line <- sprintf("%s, C%02d, %s, %s", modality, clusterID, condition, 
                        desc)
        writeLines(line, con)
    }
}
