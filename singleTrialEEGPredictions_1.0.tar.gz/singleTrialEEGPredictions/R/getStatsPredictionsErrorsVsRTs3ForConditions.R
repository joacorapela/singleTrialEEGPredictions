getStatsPredictionsErrorsVsRTs3ForConditions <-
function(sortvar, modality, clusterID, conditions, modelSignificance,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD, 
                   nResamples, conf,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    stats <- list()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        stats <- 
         c(stats, 
            list(list(condition=condition, 
                       stats=getStatsPredictionsErrorsVsRTs3ForSubjects(
                              sortvar=sortvar,
                              modality=modality,
                              clusterID=clusterID,
                              condition=condition,
                              modelSignificance=modelSignificance,
                              dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                              rtsInfo=rtsInfo,
                              dfpdsInfo=dfpdsInfo,
                              maxRT=maxRT,
                              maxSTD_D_delay=maxSTD_D_delay,
                              maxDFPD=maxDFPD,
                              nResamples=nResamples, 
                              conf=conf,
                              subjectsAndComponents=subjectsAndComponents,
                              minAndMaxSFPDOfBestPredictionsFilenamePattern=
                               minAndMaxSFPDOfBestPredictionsFilenamePattern,
                              analyzedDataFilenamePattern=
                               analyzedDataFilenamePattern, ...))))
    }
    return(stats)
}
