getPredictionsAndSFPDsForConditions <-
function(sortvar, modality, clusterID, conditions, 
                   modelSignificance,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        cDataSet <- getPredictionsAndSFPDsForSubjectsAndComponents(
                     sortvar=sortvar,
                     modality=modality,
                     clusterID=clusterID,
                     condition=condition,
                     subjectsAndComponents=subjectsAndComponents,
                     modelSignificance=modelSignificance, 
                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                     analyzedDataFilenamePattern=analyzedDataFilenamePattern,
                     ...)
        datasets <- c(datasets, cDataSet)
    }
    return(datasets)
}
