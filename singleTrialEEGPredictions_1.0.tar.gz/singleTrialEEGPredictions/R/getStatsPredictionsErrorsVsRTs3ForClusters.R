getStatsPredictionsErrorsVsRTs3ForClusters <-
function(sortvar, modality, clustersIDs, conditions, modelSignificance,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, maxSTD_D_delay, maxDFPD, 
                   nResamples, conf,
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    stats <- list()
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        stats <- 
         c(stats, 
            list(list(clusterID=clusterID, 
                       stats=getStatsPredictionsErrorsVsRTs3ForConditions(
                              sortvar=sortvar,
                              modality=modality,
                              clusterID=clusterID,
                              conditions=conditions,
                              modelSignificance=modelSignificance,
                              dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
                              rtsInfo=rtsInfo,
                              dfpdsInfo=dfpdsInfo,
                              maxRT=maxRT,
                              maxSTD_D_delay=maxSTD_D_delay,
                              maxDFPD=maxDFPD,
                              nResamples=nResamples,
                              conf=conf,
                              subjectsAndComponents=subjectsAndComponents,
                              minAndMaxSFPDOfBestPredictionsFilenamePattern=
                               minAndMaxSFPDOfBestPredictionsFilenamePattern,
                              analyzedDataFilenamePattern=
                               analyzedDataFilenamePattern, ...))))
    }
    return(stats)
}
