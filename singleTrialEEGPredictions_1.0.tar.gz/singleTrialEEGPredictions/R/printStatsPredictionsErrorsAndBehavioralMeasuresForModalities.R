printStatsPredictionsErrorsAndBehavioralMeasuresForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                      sFPStatsForModalities, 
                      dFPStats,
                      modelSignificance,
                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                      analyzedDataFilenamePattern,
                      filterSFPStatsFunc,
                      filterDFPStatsFunc, 
                      printUnselectedSFPStats,
                      printUnselectedDFPStats,
                      printSFPAndDFPStatsFunc,
                      printSFPStatsFunc,
                      printFilename) {
    con <- file(printFilename, open="wt")
    for(modality in modalities) {
        sFPStatsForClusters <-
         getItemInAVShiftList(listOfItems=sFPStatsForModalities,
                               listFieldName="stats",
                               keyFieldNames=c("modality"),
                               keyFieldValues=c(modality))
        printStatsPredictionsErrorsAndBehavioralMeasuresForClusters( 
         sortvar=sortvar,
         modality=modality,
         clustersIDs=clustersIDs,
         conditions=conditions, 
         sFPStatsForClusters=sFPStatsForClusters, 
         dFPStats=dFPStats,
         modelSignificance=modelSignificance,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         filterSFPStatsFunc=filterSFPStatsFunc,
         filterDFPStatsFunc=filterDFPStatsFunc,
         printUnselectedSFPStats=printUnselectedSFPStats,
         printUnselectedDFPStats=printUnselectedDFPStats,
         printSFPAndDFPStatsFunc=printSFPAndDFPStatsFunc,
         printSFPStatsFunc=printSFPStatsFunc,
         con=con)
    }
    close(con)
}
