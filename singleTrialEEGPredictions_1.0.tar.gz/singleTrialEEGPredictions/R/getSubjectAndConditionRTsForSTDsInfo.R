getSubjectAndConditionRTsForSTDsInfo <-
function(subjectName, condition, 
                                                              rtsForSTDsInfo) {
    for(i in 1:length(rtsForSTDsInfo)) {
        if(rtsForSTDsInfo[[i]]$subjectName==subjectName) {
            rtsForSTDsInfoForConditions <- rtsForSTDsInfo[[i]]$rtsForSTDsInfo
            return(getConditionRTsForSTDs(condition=condition,
                                           rtsForSTDsInfoForConditions=
                                            rtsForSTDsInfoForConditions))
        }
    }
    stop(sprintf("Subject %s not found", subjectName))
}
