analyzeDataRegularizedRegressionForSubjectAndComponent <-
function(modality, sortvar, clusterID, condition, 
                    subjectName,
                    component,
                    preProcessedPhaseERPIFilenamePattern, 
                    analyzedConditionsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, interactions, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, computeCoefsCIs, maxIter, convergenceTol,
                    nResamplesCoefs, nResamplesPredictions, 
                    confCIs) {
    preProcessedPhaseERPIFilename <- 
     sprintf(preProcessedPhaseERPIFilenamePattern, 
              clusterID,
              condition,
              sortvar,
              modality,
              subjectName,
              component)
    preProcessedPhaseERPI <- get(load(preProcessedPhaseERPIFilename))
    for(minSFPD in minSFPDs) {
        i <- 1
        while(i<=length(maxSFPDs) && 
               maxSFPDs[i]<=max(preProcessedPhaseERPI$sfpds)) {
            if(maxSFPDs[i]<minSFPD) {
                next
            }
            show(sprintf("Processing %s%02d: minSFPD %d, maxSFPD %d",
                         subjectName, component, minSFPD, maxSFPDs[i]))
            maxSFPD <- maxSFPDs[i]
            analyzedConditionsFilename <- 
             sprintf(analyzedConditionsFilenamePattern, clusterID, clusterID, 
                                                        condition,
                                                        sortvar, modality,
                                                        subjectName, component,
                                                        minSFPD, maxSFPD)
            res <- analyzeDataRegularizedRegression(
                    erpImage=preProcessedPhaseERPI, 
                    minSFPD=minSFPD,
                    maxSFPD=maxSFPD,
                    lambda=lambda,
                    order=order,
                    interactions=interactions, 
                    scaleData=scaleData, 
                    nGroups=nGroups,
                    a0=a0, b0=b0, c0=c0, d0=d0, 
                    computeCoefsCIs=computeCoefsCIs,
                    maxIter=maxIter,
                    convergenceTol=convergenceTol,
                    nResamplesCoefs=nResamplesCoefs, 
                    nResamplesPredictions=nResamplesPredictions, 
                    confCIs=confCIs)
            show(sprintf("predSFPDurCorCI=[%f, %f, %f]", 
                         res$predSFPDurCorCI[1],
                         res$predSFPDurCorCI[2], 
                         res$predSFPDurCorCI[3]))
            save(res, file=analyzedConditionsFilename)
            i <- i+1
        }
    }
}
