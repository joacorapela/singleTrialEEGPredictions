shuffleAndEstimateCorCoefsRegularizedRegressionForConditions <-
function(modality, sortvar, clusterID, conditions, 
                    subjectsAndComponents,
                    preProcessedPhaseERPIFilenamePattern, 
                    corCoefsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, maxIter, convergenceTol, nShuffles) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        shuffleAndEstimateCorCoefsRegularizedRegressionForSubjectsAndComponents(
         modality=modality, 
         sortvar=sortvar, 
         clusterID=clusterID, 
         condition=condition, 
         subjectsAndComponents=subjectsAndComponents,
         preProcessedPhaseERPIFilenamePattern=
          preProcessedPhaseERPIFilenamePattern,
         corCoefsFilenamePattern=corCoefsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, 
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nShuffles=nShuffles)
    }
}
