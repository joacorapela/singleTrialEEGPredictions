plotITCsForModalities <-
function(sortvar,
           modalities, 
           clustersIDs, 
           conditions,
           noctave, nvoice, nCycles, 
           itcFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ylim,
           zlim,
           cuts,
           nFreqTicks) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotITCsForClusters(sortvar=sortvar, 
                                     modality=modality,
                                     clustersIDs=clustersIDs, 
                                     conditions=conditions,
                                     noctave=noctave,
                                     nvoice=nvoice, 
                                     nCycles=nCycles,
                                     itcFilenamePattern=
                                      itcFilenamePattern,
                                     plotsFilenamePattern=
                                      plotsFilenamePattern,
                                     xlim=xlim, 
                                     ylim=ylim, 
                                     zlim=zlim,
                                     cuts=cuts, 
                                     nFreqTicks=nFreqTicks)
    }
}
