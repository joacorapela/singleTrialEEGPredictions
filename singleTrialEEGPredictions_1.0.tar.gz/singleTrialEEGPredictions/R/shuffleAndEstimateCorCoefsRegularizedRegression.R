shuffleAndEstimateCorCoefsRegularizedRegression <-
function(erpImage, minSFPD, maxSFPD, lambda, order, scaleData, 
                    nGroups, a0, b0, c0, d0, maxIter, 
                    convergenceTol, nShuffles) {
    corCoefs <- c()
    for(i in 1:nShuffles) {
        erpImage$sfpds <- sample(erpImage$sfpds)
        corCoef <- estimateCorCoefRegularizedRegression(erpImage=erpImage, 
                                                         minSFPD=minSFPD,
                                                         maxSFPD=maxSFPD,
                                                         lambda=lambda, 
                                                         order=order, 
                                                         scaleData=scaleData, 
                                                         nGroups=nGroups, 
                                                         a0=a0, 
                                                         b0=b0, 
                                                         c0=c0, 
                                                         d0=d0, 
                                                         maxIter=maxIter,
                                                         convergenceTol=
                                                          convergenceTol)
        show(sprintf("corCoef %d (out of %d): %f", i, nShuffles, corCoef))
        corCoefs <- c(corCoefs, corCoef)
    }
    return(corCoefs)
}
