shuffleAndEstimateCorCoefsRegularizedRegressionForSubjectsAndComponents <-
function(modality, sortvar, clusterID, condition, 
                    subjectsAndComponents,
                    preProcessedPhaseERPIFilenamePattern, 
                    corCoefsFilenamePattern, 
                    minSFPDs, maxSFPDs, lambda, order, scaleData, 
                    nGroups, 
                    a0, b0, c0, d0, maxIter, convergenceTol, nShuffles) {
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
        shuffleAndEstimateCorCoefsRegularizedRegressionForSubjectAndComponent(
         modality=modality, 
         sortvar=sortvar, 
         clusterID=clusterID, 
         condition=condition, 
         subjectName=subjectName,
         component=component,
         preProcessedPhaseERPIFilenamePattern=preProcessedPhaseERPIFilenamePattern,
         corCoefsFilenamePattern=corCoefsFilenamePattern,
         minSFPDs=minSFPDs,
         maxSFPDs=maxSFPDs,
         lambda=lambda,
         order=order, 
         scaleData=scaleData,
         nGroups=nGroups, 
         a0=a0, b0=b0, c0=c0, d0=d0, 
         maxIter=maxIter,
         convergenceTol=convergenceTol,
         nShuffles=nShuffles)
    }
}
