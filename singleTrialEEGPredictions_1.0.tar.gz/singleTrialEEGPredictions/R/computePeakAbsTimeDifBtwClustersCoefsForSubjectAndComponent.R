computePeakAbsTimeDifBtwClustersCoefsForSubjectAndComponent <-
function(sortvar, modality, clusterID1, clusterID2, condition,
                   subjectName, component1, component2, modelSignificance,
                   srate, lowpassFilterOrder, margin, minPeakTime,
                   onlySignificantPeaks,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    c1MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID1,
              clusterID1, condition, sortvar, modality, subjectName, component1)
    res <- readLines(c1MinAndMaxSFPDOfBestPredictionsFilename)
    c1MinSFPD <- as.integer(res[1])
    c1MaxSFPD <- as.integer(res[2])
    c2MinAndMaxSFPDOfBestPredictionsFilename <- 
     sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, clusterID2,
              clusterID2, condition, sortvar, modality, subjectName, component2)
    res <- readLines(c2MinAndMaxSFPDOfBestPredictionsFilename)
    c2MinSFPD <- as.integer(res[1])
    c2MaxSFPD <- as.integer(res[2])
    dif <- NULL
    if(!is.na(c1MinSFPD) && !is.na(c1MaxSFPD) && 
       !is.na(c2MinSFPD) && !is.na(c2MaxSFPD)) {
        c1AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID1,
                                       clusterID1,
                                       condition,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component1,
                                       c1MinSFPD,
                                       c1MaxSFPD)
        c2AnalyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                       clusterID2,
                                       clusterID2,
                                       condition,
                                       sortvar,
                                       modality,
                                       subjectName,
                                       component2,
                                       c2MinSFPD,
                                       c2MaxSFPD)
        c1AnalyzedData <- get(load(c1AnalyzedDataFilename))
        c2AnalyzedData <- get(load(c2AnalyzedDataFilename))

        if(!is.null(c1AnalyzedData$lrtRes) &&
           c1AnalyzedData$lrtRes$pValue<modelSignificance && 
           !is.null(c2AnalyzedData$lrtRes) && 
           c2AnalyzedData$lrtRes$pValue<modelSignificance) {
            peakCoefInfo1 <- getPeakCoefInfo(analyzedData=c1AnalyzedData, 
                                              srate=srate, 
                                              lowpassFilterOrder=
                                               lowpassFilterOrder, 
                                              margin=margin, 
                                              minPeakTime=minPeakTime, 
                                              onlySignificantPeaks=
                                               onlySignificantPeaks)
            peakCoefInfo2 <- getPeakCoefInfo(analyzedData=c2AnalyzedData, 
                                              srate=srate, 
                                              lowpassFilterOrder=
                                               lowpassFilterOrder, 
                                              margin=margin, 
                                              minPeakTime=minPeakTime, 
                                              onlySignificantPeaks=
                                               onlySignificantPeaks)
            if(!is.nan(peakCoefInfo1$absPeakTime) && 
               !is.nan(peakCoefInfo2$absPeakTime)) {
                dif <- peakCoefInfo1$absPeakTime-peakCoefInfo2$absPeakTime
            }
        }
    }
    return(dif)
}
