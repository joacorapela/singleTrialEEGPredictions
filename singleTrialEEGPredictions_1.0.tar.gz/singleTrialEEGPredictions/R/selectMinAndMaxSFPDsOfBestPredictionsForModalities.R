selectMinAndMaxSFPDsOfBestPredictionsForModalities <-
function(sortvar, modalities, clustersIDs, conditions, scFilenamePattern,
                   minSFPDs, maxSFPDs, analyzedDataFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        selectMinAndMaxSFPDsOfBestPredictionsForClusters(sortvar=sortvar, 
                                    modality=modality, 
                                    clustersIDs=clustersIDs, 
                                    conditions=conditions, 
                                    scFilenamePattern=
                                     scFilenamePattern,
                                    minSFPDs=minSFPDs, 
                                    maxSFPDs=maxSFPDs, 
                                    analyzedDataFilenamePattern=
                                     analyzedDataFilenamePattern,
                                    minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                     minAndMaxSFPDOfBestPredictionsFilenamePattern)
    }
}
