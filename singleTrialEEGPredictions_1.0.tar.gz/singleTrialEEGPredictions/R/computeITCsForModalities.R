computeITCsForModalities <-
function(modalities, 
                                      sortvar,
                                      clustersIDs,
                                      conditions,
                                      noctave, nvoice, nCycles, 
                                      minTime, 
                                      maxTime, 
                                      significance,
                                      conf,
                                      peakFromTime, peakToTime, 
                                      peakFromFreq, peakToFreq,
                                      nResamples,
                                      erpimageFilenamePattern, 
                                      itcsFilenamePattern,
                                      scFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        computeITCsForClusters(modality=modality, 
                                sortvar=sortvar,
                                clustersIDs=clustersIDs,
                                conditions=conditions,
                                noctave=noctave, 
                                nvoice=nvoice, 
                                nCycles=nCycles, 
                                minTime=minTime, 
                                maxTime=maxTime,
                                significance=significance,
                                conf=conf,
                                peakFromTime=peakFromTime, 
                                peakToTime=peakToTime,
                                peakFromFreq=peakFromFreq, 
                                peakToFreq=peakToFreq,
                                nResamples=nResamples, 
                                erpimageFilenamePattern=
                                 erpimageFilenamePattern,
                                itcsFilenamePattern=itcsFilenamePattern,
                                scFilenamePattern=scFilenamePattern)
    }
}
