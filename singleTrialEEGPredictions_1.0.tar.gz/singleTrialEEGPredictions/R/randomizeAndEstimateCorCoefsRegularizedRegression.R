randomizeAndEstimateCorCoefsRegularizedRegression <-
function(sortvar, modality, clusterID, condition, 
                   subjectName,
                   component,
                   minSFPD, maxSFPD, lambda, order, scaleData, 
                   nGroups, 
                   a0, b0, c0, d0, maxIter, convergenceTol, nRandomizations,
                   clipFrom, clipTo, srate, 
                   stdsNextDsLatenciesInfo,
                   stdsNextCuesLatenciesInfo,
                   stdsNextEOBsLatenciesInfo,
                   phaseERPImageFilenamePattern, 
                   timesPPPhaseERPIFilenamePattern,
                   corCoefsFilenamePattern, 
                   plotSteps,
                   averageTrialsWinSize,
                   plotsFilenamePattern,
                   width, height) {
    phaseERPImageFilename <- sprintf(phaseERPImageFilenamePattern, 
                                      clusterID, 
                                      condition, 
                                      sortvar, 
                                      modality, 
                                      subjectName,
                                      component)
    phaseERPImage <- get(load(phaseERPImageFilename))
    timesPPPhaseERPIFilename <- sprintf(timesPPPhaseERPIFilenamePattern,
                                         clusterID, 
                                         condition, 
                                         sortvar, 
                                         modality, 
                                         subjectName,
                                         component)
    significantTimes <- get(load(timesPPPhaseERPIFilename))
    subjectSTDsNextDsLatencies <- 
     getItemInAVShiftList(listOfItems=stdsNextDsLatenciesInfo, 
                           listFieldName="stdsNextDsLatenciesInfo",
                           keyFieldNames=c("subjectName", "modality",
                                           "condition"),
                           keyFieldValues=c(subjectName, modality,
                                                         condition))
    if(condition%in%c("switchvision", "switchaudition")) {
        subjectSTDsNextCuesLatencies <- 
         getItemInAVShiftList(listOfItems=stdsNextCuesLatenciesInfo, 
                               listFieldName="stdsNextCuesLatenciesInfo",
                               keyFieldNames=c("subjectName", "modality",
                                               "condition"),
                               keyFieldValues=c(subjectName, modality,
                                                             condition))
    } else {
        subjectSTDsNextCuesLatencies <- NA
    }
    subjectSTDsNextEOBsLatencies <- 
     getItemInAVShiftList(listOfItems=stdsNextEOBsLatenciesInfo, 
                           listFieldName="stdsNextEOBsLatenciesInfo",
                           keyFieldNames=c("subjectName", "modality",
                                           "condition"),
                           keyFieldValues=c(subjectName, modality,
                                                         condition))
    corCoefs <- c()
    for(i in 1:nRandomizations) {
        preProcessedERPI <- 
         randomizeSTDsAndPreProcessERPI(phaseERPImage=phaseERPImage, 
                                         clipFrom=clipFrom, clipTo=clipTo, 
                                         srate=srate, 
                                         significantTimes=significantTimes, 
                                         stdsNextDsLatenciesInfo=
                                          subjectSTDsNextDsLatencies, 
                                         stdsNextCuesLatenciesInfo=
                                          subjectSTDsNextCuesLatencies, 
                                         stdsNextEOBsLatenciesInfo=
                                          subjectSTDsNextEOBsLatencies, 
                                         plotSteps=plotSteps, 
                                         averageTrialsWinSize=
                                          averageTrialsWinSize, 
                                         plotsFilenamePattern=
                                          plotsFilenamePattern, 
                                         width=width, height=height)
        corCoef <- estimateCorCoefRegularizedRegression(erpImage=
                                                          preProcessedERPI, 
                                                         minSFPD=minSFPD,
                                                         maxSFPD=maxSFPD,
                                                         lambda=lambda, 
                                                         order=order, 
                                                         scaleData=scaleData, 
                                                         nGroups=nGroups, 
                                                         a0=a0, 
                                                         b0=b0, 
                                                         c0=c0, 
                                                         d0=d0, 
                                                         maxIter=maxIter,
                                                         convergenceTol=
                                                          convergenceTol)
        show(sprintf("corCoef %d (out of %d): %f", i, nRandomizations, corCoef))
        corCoefs <- c(corCoefs, corCoef)
    }
    return(corCoefs)
}
