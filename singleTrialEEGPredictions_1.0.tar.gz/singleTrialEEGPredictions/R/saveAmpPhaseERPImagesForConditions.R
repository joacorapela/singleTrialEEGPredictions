saveAmpPhaseERPImagesForConditions <-
function(sortvar, 
                                                modality, 
                                                clusterID, 
                                                conditions, 
                                                subjectsAndComponents,
                                                noctave, nvoice, nCycles, 
                                                minTime, 
                                                maxTime, 
                                                shuffleSFPDs,
                                                sfpdsInfo,
                                                itcsPeaksFilenamePattern, 
                                                erpimageFilenamePattern,
                                                apERPImagesFilenamePattern,
                                                scFilenamePattern) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        apERPImages <- 
         saveAmpPhaseERPImagesForCondition(sortvar=sortvar, 
                                            modality=modality,
                                            clusterID=clusterID,
                                            condition=condition,
                                            subjectsAndComponents=
                                             subjectsAndComponents,
                                            noctave=noctave,
                                            nvoice=nvoice,
                                            nCycles=nCycles,
                                            minTime=minTime, 
                                            maxTime=maxTime, 
                                            shuffleSFPDs=shuffleSFPDs,
                                            sfpdsInfo=sfpdsInfo,
                                            itcsPeaksFilenamePattern=
                                             itcsPeaksFilenamePattern,
                                            erpimageFilenamePattern=
                                             erpimageFilenamePattern,
                                            apERPImagesFilenamePattern=
                                             apERPImagesFilenamePattern)
    }
}
