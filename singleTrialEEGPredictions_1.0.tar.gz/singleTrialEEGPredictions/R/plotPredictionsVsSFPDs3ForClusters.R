plotPredictionsVsSFPDs3ForClusters <-
function(sortvar, modality, clustersIDs, conditions, 
                   adjustedPValuesDF,
                   corCoefAnnotationFunction,
                   subjectsAndComponents, scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height, ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        if(is.null(subjectsAndComponents)) {
            scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
            if(is.null(scFilename)) {
                stop("arguments subjectsAndComponents or scFilenamePattern should be provided")
            }
            subjectsAndComponentsInCluster <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                                scFilename=scFilename)
        } else {
            subjectsAndComponentsInCluster <- subjectsAndComponents
        }
        plotPredictionsVsSFPDs3ForConditions(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID, 
         conditions=conditions,
         adjustedPValuesDF=adjustedPValuesDF,
         corCoefAnnotationFunction=
          corCoefAnnotationFunction,
         subjectsAndComponents=subjectsAndComponentsInCluster,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=
         plotsFilenamePattern,
         width=width, 
         height=height,
         ...)
    }
}
