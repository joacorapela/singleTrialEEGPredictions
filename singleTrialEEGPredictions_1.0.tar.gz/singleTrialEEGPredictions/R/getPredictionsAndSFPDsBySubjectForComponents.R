getPredictionsAndSFPDsBySubjectForComponents <-
function(sortvar, subject, modality, clusterID, condition, components, 
                   modelSignificance,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    datasets <- list()
    for(i in 1:length(components)) {
        subjectName <- subject
        component <- components[i]
        show(sprintf("Processing component %02d", component))
        minAndMaxSFPDOfBestPredictionsFilename <- 
         sprintf(minAndMaxSFPDOfBestPredictionsFilenamePattern, 
                  clusterID, clusterID, condition, sortvar, modality, 
                  subjectName, component)
        res <- readLines(minAndMaxSFPDOfBestPredictionsFilename)
        minSFPD <- as.integer(res[1])
        maxSFPD <- as.integer(res[2])
        if(!is.na(minSFPD) && !is.na(maxSFPD)) {
            analyzedDataFilename <- sprintf(analyzedDataFilenamePattern,
                                             clusterID,
                                             clusterID,
                                             condition,
                                             sortvar,
                                             modality,
                                             subjectName,
                                             component,
                                             minSFPD,
                                             maxSFPD)
            analyzedData <- get(load(analyzedDataFilename))
            if(!is.null(analyzedData$lrtRes) &&
               analyzedData$lrtRes$pValue<modelSignificance) {

                metaData <- list(modality=modality, clusterID=clusterID,
                                                    condition=condition, 
                                                    component=component)
                cDataset <- list(x=analyzedData$predictions, 
                                  y=analyzedData$data[,1], 
                                  metaData=metaData)
                datasets <- c(datasets, list(cDataset))
            }
        }
    }
    return(datasets)
}
