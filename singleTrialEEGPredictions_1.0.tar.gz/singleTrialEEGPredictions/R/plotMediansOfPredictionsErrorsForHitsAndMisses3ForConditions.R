plotMediansOfPredictionsErrorsForHitsAndMisses3ForConditions <-
function(sortvar, modality, clusterID, conditions,
                   getStatsDifAnnotationFunction,
                   dsAndPreviousSTDsInfo,
                   rtsInfo,
                   dfpdsInfo,
                   maxRT, 
                   maxSTD_D_delay,
                   maxDFPD,
                   nResamples,
                   conf,
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern,
                   plotsFilenamePattern,
                   width, height,
                   ...) {
    for(condition in conditions) {
        show(sprintf("Processing condition %s", condition))
        plotMediansOfPredictionsErrorsForHitsAndMisses3ForSubjects(
         sortvar=sortvar, 
         modality=modality,
         clusterID=clusterID,
         condition=condition,
         getStatsDifAnnotationFunction=getStatsDifAnnotationFunction,
         dsAndPreviousSTDsInfo=dsAndPreviousSTDsInfo,
         rtsInfo=rtsInfo,
         dfpdsInfo=dfpdsInfo,
         maxRT=maxRT,
         maxSTD_D_delay=maxSTD_D_delay,
         maxDFPD=maxDFPD,
         nResamples=nResamples,
         conf=conf,
         subjectsAndComponents=subjectsAndComponents,
         minAndMaxSFPDOfBestPredictionsFilenamePattern=
          minAndMaxSFPDOfBestPredictionsFilenamePattern,
         analyzedDataFilenamePattern=analyzedDataFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         width=width, height=height,
         ...)
    }
}
