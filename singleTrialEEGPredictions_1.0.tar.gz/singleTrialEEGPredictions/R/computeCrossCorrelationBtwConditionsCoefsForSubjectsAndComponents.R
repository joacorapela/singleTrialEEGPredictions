computeCrossCorrelationBtwConditionsCoefsForSubjectsAndComponents <-
function(sortvar, modality, clusterID, condition1, condition2, 
                   minOverlapMS, srate,
                   modelSignificance, nResamples, 
                   subjectsAndComponents,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    subjectsNames <- c()
    components <- c()
    correlations <- c()
    pValues <- c()
    for(i in 1:nrow(subjectsAndComponents)) {
        subjectName <- subjectsAndComponents[i, "subjectName"]
        component <- subjectsAndComponents[i, "component"]
        show(sprintf("Processing subject %s and component %02d", subjectName,
                     component))
         res <- 
          computeCrossCorrelationBtwConditionsCoefsForSubjectAndComponent(
           sortvar=sortvar,
           modality=modality,
           clusterID=clusterID,
           condition1=condition1,
           condition2=condition2,
           minOverlapMS=minOverlapMS,,
           srate=srate,,
           subjectName=subjectName,
           component=component,
           modelSignificance=modelSignificance,
           nResamples=nResamples,
           minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
           analyzedDataFilenamePattern=analyzedDataFilenamePattern,
           ...)
        if(!is.null(res)) {
            subjectsNames <- c(subjectsNames, subjectName)
            components <- c(components, component)
            correlations <- c(correlations, res[1])
            pValues <- c(pValues, res[2])
        }
    }
    if(length(subjectsNames)>0) {
        return(data.frame(subjectName=subjectsNames, component=components,
                                                     correlation=correlations,
                                                     pValue=pValues))
    } else {
        return(data.frame())
    }
}
