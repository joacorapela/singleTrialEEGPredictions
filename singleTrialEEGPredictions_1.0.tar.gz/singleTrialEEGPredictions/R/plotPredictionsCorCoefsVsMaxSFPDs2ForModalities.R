plotPredictionsCorCoefsVsMaxSFPDs2ForModalities <-
function(sortvar, modalities, clustersIDs, conditions, maxSFPDs,
                   nResamples, modelSignificance, rConf,
                   subjectsAndComponents, 
                   scFilenamePattern,
                   analyzedConditionsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        plotPredictionsCorCoefsVsMaxSFPDs2ForClusters(
         sortvar=sortvar, 
         modality=modality, 
         clustersIDs=clustersIDs, 
         conditions=conditions, 
         maxSFPDs=maxSFPDs,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         rConf=rConf,
         subjectsAndComponents=subjectsAndComponents,
         scFilenamePattern=scFilenamePattern,
         analyzedConditionsFilenamePattern=analyzedConditionsFilenamePattern,
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         ...)
    }
}
