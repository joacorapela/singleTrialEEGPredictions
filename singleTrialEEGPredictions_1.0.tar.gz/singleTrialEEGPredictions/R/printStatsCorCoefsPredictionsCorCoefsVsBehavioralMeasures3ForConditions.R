printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForConditions <-
function(sortvar, modality, clusterID, conditions, filterFunc, 
                   getConditionStatsDescFunc, statsFilenamePattern, con) {
    for(condition in conditions) {
        printStatsCorCoefsPredictionsCorCoefsVsBehavioralMeasures3ForCondition(
         sortvar=sortvar, 
         modality=modality, 
         clusterID=clusterID,
         condition=condition,
         filterFunc=filterFunc,
         getConditionStatsDescFunc=getConditionStatsDescFunc,
         statsFilenamePattern=statsFilenamePattern,
         con=con)
    }
}
