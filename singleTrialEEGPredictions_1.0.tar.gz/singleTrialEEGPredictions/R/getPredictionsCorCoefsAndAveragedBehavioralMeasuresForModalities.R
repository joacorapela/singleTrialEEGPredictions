getPredictionsCorCoefsAndAveragedBehavioralMeasuresForModalities <-
function(sortvar, modalities, clustersIDs, conditions,
                   errorRatesAndMeanRTsStats, 
                   getSubjectBehavioralMeasureCIFunc, 
                   scFilenamePattern,
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    predCorCoefsAndABMs <- list()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        mPredCorCoefsAndABMs <- getPredictionsCorCoefsAndAveragedBehavioralMeasuresForClusters(
                                 sortvar=sortvar,
                                 modality=modality,
                                 clustersIDs=clustersIDs,
                                 conditions=conditions,
                                 errorRatesAndMeanRTsStats=errorRatesAndMeanRTsStats,
                                 getSubjectBehavioralMeasureCIFunc=getSubjectBehavioralMeasureCIFunc,
                                 scFilenamePattern=scFilenamePattern,
                                 minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                  minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                 analyzedDataFilenamePattern=analyzedDataFilenamePattern)
        if(length(mPredCorCoefsAndABMs)>0) {
            predCorCoefsAndABMs <- c(predCorCoefsAndABMs, mPredCorCoefsAndABMs)
        }
    }
    return(predCorCoefsAndABMs)
}
