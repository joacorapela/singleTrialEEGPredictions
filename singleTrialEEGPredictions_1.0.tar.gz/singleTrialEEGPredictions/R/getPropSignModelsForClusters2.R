getPropSignModelsForClusters2 <-
function(sortvar, modality, clustersIDs, condition, modelSignificance, 
                   scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern) {
    conditionProps <- c()
    for(clusterID in clustersIDs) {
        scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
        subjectsAndComponents <-
         getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                            scFilename=scFilename)
        nSignModels <- 
         getNSignModelsForSubjects2(sortvar=sortvar, 
                                     modality=modality,
                                     clusterID=clusterID,
                                     condition=condition,
                                     modelSignificance=modelSignificance,
                                     subjectsAndComponents=
                                      subjectsAndComponents,
                                     minAndMaxSFPDOfBestPredictionsFilenamePattern=
                                      minAndMaxSFPDOfBestPredictionsFilenamePattern,
                                     analyzedDataFilenamePattern=
                                      analyzedDataFilenamePattern)
        clusterProps <- nSignModels/nrow(subjectsAndComponents)
        conditionProps <- c(conditionProps, clusterProps)
    }
    return(conditionProps)
}
