buildModalitySFPDsInfo <-
function(subjectName, modality, conditions, 
                                                sfpdsInfoFilenamePattern) {
    sfpdsInfo <- list()
    for(condition in conditions) {
        show(sprintf('Processing condition %s', condition))
        conditionSFPDsInfo <- buildConditionSFPDsInfo(
                               subjectName=subjectName, 
                               modality=modality,
                               condition=condition,
                               sfpdsInfoFilenamePattern=
                                sfpdsInfoFilenamePattern)
        sfpdsInfo <- c(sfpdsInfo, list(list(condition=condition, 
                                             sfpdsInfo=conditionSFPDsInfo)))
    }
    return(sfpdsInfo)
}
