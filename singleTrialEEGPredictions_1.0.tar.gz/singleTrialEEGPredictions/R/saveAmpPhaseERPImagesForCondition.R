saveAmpPhaseERPImagesForCondition <-
function(sortvar, 
                                                modality, 
                                                clusterID, 
                                                condition, 
                                                subjectsAndComponents,
                                                noctave, nvoice, nCycles, 
                                                minTime, 
                                                maxTime, 
                                                shuffleSFPDs,
                                                sfpdsInfo,
                                                itcsPeaksFilenamePattern, 
                                                erpimageFilenamePattern,
                                                apERPImagesFilenamePattern) {
    peaksInfoFilename <- sprintf(itcsPeaksFilenamePattern, clusterID, condition,
                                                           sortvar, modality, 
                                                           noctave, nvoice, 
                                                           nCycles)
    condERPImageFilenamePattern <- sprintf(erpimageFilenamePattern, clusterID, 
                                                                      condition,
                                                                      sortvar, 
                                                                      modality)
    
    resLoadData <- loadERPImageData(filenamesPattern=
                                     condERPImageFilenamePattern)
    subjectsNames <- resLoadData$subjectsNames
    components <- resLoadData$components
    epochEventIDs <- resLoadData$epochEventIDs
    trials <- resLoadData$data
    times <- resLoadData$times
    srate <- resLoadData$metaData$srate
    if(is.na(minTime)) {
        minTime <- min(resLoadData$times)
    }
    if(is.na(maxTime)) {
        maxTime <- max(resLoadData$times)
    }
    peaksInfo <- readPeaksInfo(filename=peaksInfoFilename)
    for(subjectName in unique(subjectsNames)) {
        subjectComponents <-
         getSubjectComponents(subjectName=subjectName,
                               subjectsAndComponents=subjectsAndComponents)
        for(component in subjectComponents) {
            show(sprintf("Processing subject %s and component %02d", 
                         subjectName, component))
            apERPImagesFilename <- sprintf(apERPImagesFilenamePattern,
                                            clusterID, condition, sortvar, 
                                            modality, subjectName, component)
            scPeakITCInfo <- 
             getSubjectAndComponentPeakTimeFreqInfo(subjectName=subjectName, 
                                                     component=component,
                                                     peaksInfo=peaksInfo)
            scCases <- getSubjectAndComponentCases(subjectName=subjectName, 
                                                    component=component,
                                                    subjectsNames=subjectsNames,
                                                    components=components)
            scEpochEventIDs <- epochEventIDs[scCases]
            sSFPDsInfo <- 
             getSubjectModalityAndConditionSFPDsInfo(sfpdsInfo=sfpdsInfo, 
                                              subjectName=subjectName,
                                              modality=modality,
                                              condition=condition)
            subjectSFPDs <- getSFPDsForNonTargetsUREvents(sfpds=sSFPDsInfo, 
                                                           nonTargetsUREvents=
                                                            scEpochEventIDs)
            scTrials <- trials[, scCases]
            outliersIDs <- outbox(subjectSFPDs, mbox=TRUE)$out.id
            outliersEpochEventIDs <- scEpochEventIDs[outliersIDs]
            if(length(outliersIDs[1])>0) {
                scTrials <- scTrials[, -outliersIDs]
                scEpochEventIDs <- scEpochEventIDs[-outliersIDs]
                subjectSFPDs <- subjectSFPDs[-outliersIDs]
            }
            saveAmpPhaseERPImagesForTrials(
             subjectName=subjectName,
             component=component,
             peakITCFreq=scPeakITCInfo$freq,
             nCycles=nCycles,
             trials=scTrials,
             epochEventIDs=scEpochEventIDs,
             sfpds=subjectSFPDs,
             sfpdsOutliers=outliersEpochEventIDs,
             times=times,
             srate=srate,
             minTime=minTime, 
             maxTime=maxTime,
             shuffleSFPDs=shuffleSFPDs,
             filename=apERPImagesFilename)
        }
    }
}
