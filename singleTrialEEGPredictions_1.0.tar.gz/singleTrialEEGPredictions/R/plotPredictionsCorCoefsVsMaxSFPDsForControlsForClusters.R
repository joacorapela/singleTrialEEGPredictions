plotPredictionsCorCoefsVsMaxSFPDsForControlsForClusters <-
function(sortvar, modality, clustersIDs, conditions, minSFPD, maxSFPDs,
                   nResamples, modelSignificance, ciConf,
                   subjectsAndComponents, 
                   coefsFilenamePattern, 
                   plotsFilenamePattern,
                   xlab, ylab, main, 
                   ...) {
    for(clusterID in clustersIDs) {
        show(sprintf("Processing cluster %d", clusterID))
        plotPredictionsCorCoefsVsMaxSFPDsForControlsForConditions(
         sortvar=sortvar, 
         modality=modality, 
         clusterID=clusterID, 
         conditions=conditions, 
         minSFPD=minSFPD,
         maxSFPDs=maxSFPDs,
         nResamples=nResamples,
         modelSignificance=modelSignificance,
         ciConf=ciConf,
         subjectsAndComponents=subjectsAndComponents,
         coefsFilenamePattern=coefsFilenamePattern, 
         plotsFilenamePattern=plotsFilenamePattern,
         xlab=xlab, 
         ylab=ylab, 
         main=main, 
         ...)
    }
}
