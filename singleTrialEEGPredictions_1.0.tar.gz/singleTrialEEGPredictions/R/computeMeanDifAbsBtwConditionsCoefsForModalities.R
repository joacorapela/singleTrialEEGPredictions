computeMeanDifAbsBtwConditionsCoefsForModalities <-
function(sortvar, modalities, clustersIDs, condition1, condition2, 
                   modelSignificance, nResamples, scFilenamePattern, 
                   minAndMaxSFPDOfBestPredictionsFilenamePattern,
                   analyzedDataFilenamePattern, ...) {
    answer <- c()
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        res <- 
         computeMeanDifAbsBtwConditionsCoefsForClusters(
          sortvar=sortvar,
          modality=modality,
          clustersIDs=clustersIDs,
          condition1=condition1,
          condition2=condition2,
          modelSignificance=modelSignificance,
          nResamples=nResamples,
          scFilenamePattern=scFilenamePattern,
          minAndMaxSFPDOfBestPredictionsFilenamePattern=
           minAndMaxSFPDOfBestPredictionsFilenamePattern,
          analyzedDataFilenamePattern=
           analyzedDataFilenamePattern, 
          ...)
        answer <- rbind(answer, 
                         cbind(modality=rep(modality, times=nrow(res)), res))
    }
    return(answer)
}
