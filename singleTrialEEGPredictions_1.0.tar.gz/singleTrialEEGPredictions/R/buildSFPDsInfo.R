buildSFPDsInfo <-
function(subjectsNames, modalities, conditions, 
                                          sfpdsInfoFilenamePattern) {
    sfpdsInfo <- list()
    for(subjectName in subjectsNames) {
        show(sprintf('Processing subject %s', subjectName))
        subjectSFPDsInfo <- buildSubjectSFPDsInfo(
                             subjectName=subjectName,
                             modalities=modalities,
                             conditions=conditions, 
                             sfpdsInfoFilenamePattern=sfpdsInfoFilenamePattern)
        sfpdsInfo <- c(sfpdsInfo, list(list(subjectName=subjectName, 
                                             sfpdsInfo=subjectSFPDsInfo)))
    }
    return(sfpdsInfo)
}
