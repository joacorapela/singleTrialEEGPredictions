saveAmpPhaseERPImagesForModalities <-
function(sortvar, 
                                                modalities, 
                                                clustersIDs, 
                                                conditions, 
                                                noctave, nvoice, nCycles, 
                                                minTime, 
                                                maxTime, 
                                                shuffleSFPDs,
                                                sfpdsInfo,
                                                itcsPeaksFilenamePattern, 
                                                erpimageFilenamePattern,
                                                apERPImagesFilenamePattern,
                                                scFilenamePattern) {
    for(modality in modalities) {
        show(sprintf("Processing modality %s", modality))
        saveAmpPhaseERPImagesForClusters(sortvar=sortvar,
                                          modality=modality,
                                          clustersIDs=clustersIDs,
                                          conditions=conditions,
                                          noctave=noctave,
                                          nvoice=nvoice,
                                          nCycles=nCycles,
                                          minTime=minTime, 
                                          maxTime=maxTime, 
                                          shuffleSFPDs=shuffleSFPDs,
                                          sfpdsInfo=sfpdsInfo,
                                          itcsPeaksFilenamePattern=
                                           itcsPeaksFilenamePattern,
                                          erpimageFilenamePattern=
                                           erpimageFilenamePattern,
                                          apERPImagesFilenamePattern=
                                           apERPImagesFilenamePattern,
                                          scFilenamePattern=scFilenamePattern)
    }
}
