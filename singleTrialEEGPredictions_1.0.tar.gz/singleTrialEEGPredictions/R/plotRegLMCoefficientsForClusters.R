plotRegLMCoefficientsForClusters <-
function(sortvar, 
           modality, 
           clustersIDs,
           conditions,
           unstandardize,
           subjectsAndComponents,
           scFilenamePattern,
           minSFPDs, maxSFPDs,
           analyzedConditionsFilenamePattern,
           plotsFilenamePattern,
           xlim,
           ...) {
    for(clusterID in clustersIDs) {
        if(is.null(subjectsAndComponents)) {
            scFilename <- sprintf(scFilenamePattern, clusterID, sortvar)
            if(is.null(scFilename)) {
                stop("arguments subjectsAndComponents or scFilenamePattern should be provided")
            }
            subjectsAndComponentsInCluster <-
             getSubjectsAndComponentsInCluster(clusterID=clusterID, 
                                                scFilename=scFilename)
        } else {
            subjectsAndComponentsInCluster <- subjectsAndComponents
        }
        show(sprintf("Processing cluster %s", clusterID))
        plotRegLMCoefficientsForConditions(sortvar=sortvar, 
                                        modality=modality,
                                        clusterID=clusterID, 
                                        conditions=conditions,
                                        unstandardize=unstandardize,
                                        subjectsAndComponents=
                                         subjectsAndComponentsInCluster,
                                        minSFPDs=minSFPDs, maxSFPDs=maxSFPDs,
                                        analyzedConditionsFilenamePattern=
                                         analyzedConditionsFilenamePattern,
                                        plotsFilenamePattern=
                                         plotsFilenamePattern,
                                        xlim=xlim,
                                        ...)
    }
}
